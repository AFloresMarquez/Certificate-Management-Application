<?php
	//10/10/22 A.Flores MOD 1L: modified $pdo for new database cs_certificate_database
$pdo = new PDO('mysql:host=localhost;dbname=cs_certificate_database;charset=utf8', 'certificateUser', '(Xpv6Y)A7Lunxq0t');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);