<!doctype html>
<html lang="en-US">
	<head>
			<!--10/10/22 AFLores NEW 6L: link tags for favicon-->
		<meta charset="utf-8" meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
		<link rel="manifest" href="site.webmanifest">
		<link rel="stylesheet" href="certificates.css"> <!--10/10/22 AFLores MOD 1L: changed jokes.css to certificates.css-->
		<script>
				//11/5/22 AFlores NEW 17L: implemented load event listener
			window.addEventListener("load", () => {
			let current = 0;
				//11/5/22 AFlores NEW 10L: for loop goes through all links in page and adds style class to current active link 
			for (var i = 0; i < document.links.length; i++) {
					//11/5/22 AFlores NEW 3L: slice url to and compare to value from links array. Set current index number to current if it returns true 
				if (document.links[i].href.slice(63) == document.URL.slice(63)) {
					current = i;
					break;
				}	//11/5/22 AFlores NEW 1L: Else current = -1
				else {current = -1;}
			}
				//11/5/22 AFlores NEW 3L: if current is not -1, set class style of link to current
			if (current != -1){
				document.links[current].className = 'current'; 
			}
				//11/16/22 AFlores NEW 1L: set var to last mod
			var modDate = new Date( document.lastModified );
				//11/16/2022 A.Flores NEW 1L:  output date of local date and last mod
			document.getElementById('lastMOD').innerHTML += "This page was last modified " + modDate.toLocaleString();});
				//11/16/2022 A.Flores NEW 1L: method adds functionality to back to top button
			function topFunction() {
 				document.body.scrollTop = 0;
  				document.documentElement.scrollTop = 0;}
				//11/16/2022 A.Flores NEW 7L: hides class responsive if class is already active in element. Else add class responsive to element.
			function showMenu() {
				var x = document.getElementById("navlist");
  				if (x.className === "navlistclass") {
					x.className += " responsive";
				} else {
					x.className = "navlistclass";}
			}
		</script>
		<title><?=$title?></title>
	</head>
	<body>
	<nav>
		<header>
			 	<!--10/09/22 A.Flores DEL 1L: removed header text-->
			 <img src="cslogo.svg" alt="CS Certificates Logo" width="300px" height="220px" style="display: block;margin-right: auto;margin-left: auto;"/>
		</header>
				<!-- 11/16/2022 A.Flores NEW 1L: call showMenu() if navigation icon is clicked on-->
			<a href="javascript:void(0);" class="icon" onclick="showMenu()">&#9776;</a>
		<div id="navlist" class="navlistclass">
		<ul>
	        <li><a href="index.php">Home</a></li>	
			<li><a href="index.php?certificatedetails/list">Certificates</a></li>	
            <li><a href="index.php?certificate/list">Recipients List</a></li>
			<li><a href="index.php?certificate/aboutus">About Us</a></li>
			<li><a href="index.php?certificate/contactus">Contact Us</a></li>
			<li><a href="index.php?certificate/faq">FAQ</a></li>
			<li><a href="index.php?user/register">Register Account</a></li>
				<!--11/5/22 A.Flores MOD 8L: if user is logged in, then show links-->
	    	<?php if ($loggedIn): ?>   
	    		<li><a href="index.php?logout">Log out</a></li>
			<?php else: ?>
	      		<li><a href="index.php?login">Log in</a></li>
			<?php endif; ?>
		</ul>
			<!--11/5/22 A.Flores MOD 8L: if user is logged in, then show links-->
		<?php if ($loggedIn): ?> 
		<ul>
			<li><a href="index.php?category/list">Manage Categories</a></li> 
			<li><a href="index.php?certificate/manage">Manage Recipients</a></li>
			<li><a href="index.php?certificatedetails/manage">Manage Certificates</a></li>
			<li><a href="index.php?requiredcourses/manage">Manage Courses</a></li>
			<li><a href="index.php?user/list">Manage User</a></li> 
		</ul>
		<?php endif; ?>
		</div>
	</nav>

	<div id="page">
			<!--10/10/22 A.Flores NEW 3L: implemented sidebar with link to ULV certficates-->
		<aside id="sidebar">
			<p>Check out the information of Computer Science Cerificates on the University of La Verne Computer Science Page: <a href="https://artsci.laverne.edu/compsci/" target="_blank">Link</a></p>
		</aside>
		<main id="main">
			<?=$output?>
		</main>
	</div>
		
	<footer>
		<!--10/10/22 A.Flores MOD 21L: Added text base navigation and personal email-->
		Computer Science Certificate Internet Application &copy; 2022<br>
		<a href="mailto:antonio.floresmarquez@laverne.edu">antonio.floresmarquez@laverne.edu</a><br>
	      	<!--10/10/22 A.Flores NEW 17L: add navigation to footor and best view-->
		 <i> 
	 	 <a href="index.php">Home</a> | 
	      	 <!--10/10/22 A.Flores MOD 1L: joke list changed to workout list-->
		 <a href="index.php?certificatedetails/list">Certificates</a> |
		 <a href="index.php?certificate/list">Recipients List</a> |
		 <a href="index.php?user/list">Manage User</a> |
		 	<!--11/5/22 A.Flores MOD 8L: if user is logged in, then show links. Else show login link-->
	   	 <?php if ($loggedIn): ?>    
	    	<a href="index.php?logout">Log out</a> | 
			<a href="index.php?category/list">Manage Category</a> |
		 	<a href="index.php?certificate/manage">Manage Recipients</a> |
		 	<a href="index.php?certificatedetails/manage">Manage Certificates</a> | 
			<a href="index.php?requiredcourses/manage">Manage Courses</a> |
			<a href="index.php?user/list">Manage User</a> | 
		<?php else: ?>
			<a href="index.php?login">Log in</a> | 
		<?php endif; ?>
			<a href="index.php?user/register">Register</a> | 
		     	<!--10/10/22 A.Flores NEW 3L: Added new about us and contact us page-->
			<a href="index.php?certificate/aboutus">About Us</a> | 
			<a href="index.php?certificate/contactus">Contact Us</a> | 
			<a href="index.php?certificate/faq">FAQ</a> |
		</i><br>
		Best Viewed on Chrome and Firefox
			<!--10/16/22 A.Flores NEW 3L: show last modified results-->
		<div id ="lastMOD"></div>	
	</footer>
	</body>
</html>