	<!--10/21/22 A.Flores NEW 1L: added header tag for login page-->
<h2>Computer Science Certificates - Login Form</h2><br>
	<!--11/26/22 A.Flores NEW 3L: if $error is set, then display errors-->
<?php if (isset($error)):?>
	<div class="errors"><?=$error;?></div>
<?php endif; ?>
	<!--11/26/22 A.Flores MOD 9L: added tabindexs and accesskeys for inputs in form-->
<form method="post" action="">
	<label for="email">Your email address</label>
	<input type="text" id="email" name="email" tabindex="1" accesskey="e">

	<label for="password">Your password</label>
	<input type="password" id="password" name="password" tabindex="2" accesskey="p">

	<input type="submit" name="login" value="Log in" tabindex="3" accesskey="s">
</form>