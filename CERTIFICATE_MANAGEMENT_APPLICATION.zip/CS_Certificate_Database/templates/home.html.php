	<!--10/15/22 A.Flores NEW 11L: div with class for center style-->
<div class=".sectioncentered ">
    <h2>Computer Science Certificates - Home</h2><br>
    	<!--10/15/22 A.Flores NEW 1L: Inserted responsive image-->
    <img src="bookshelf.jpg" alt="Book Shelf Image by Louis from Pixabay" class="responsiveimage">

    <br><p>Welcome to the Computer Science Certificate Web Application!<br><br>
        The CS Certificate Web Application contains the information of computer science certificates and reicipents. Explore the web application to view
        information about certificates and the list of reicipents. The plan of this website is to help keep track of 
        reicipents of computer science certificates. Go to the Reicipent List page to view reicipent or log into your
        account to add reicipent to the database on the Manage reicipent page.</p>
</div>