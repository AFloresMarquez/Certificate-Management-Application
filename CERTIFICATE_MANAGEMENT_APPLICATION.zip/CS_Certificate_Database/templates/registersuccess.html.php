<h2>Registration Successful</h2>
    <!--11/26/22 A.Flores MOD 1L: Change paragraph to fit new context-->
<p>You are now registered on the Computer Science Certificate Web Application.</p>