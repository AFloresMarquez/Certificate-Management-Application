  <!--11/17/22 A.Flores NEW 1L: Added title header to page-->
<h2>Computer Science Certificates - Manage Certificates</h2><br>
<div class="list">
    <!--11/18/22 A.Flores NEW 2L: Added add button to add certificates-->
  <br><a href="index.php?certificatedetails/edit">
    <input type="button" value="Add" style="width: 97px; height: 47px; font-size: 18px; margin-left: 8px; float: none;"></a>
    <!--11/18/22 A.Flores NEW 17L: foreach loop prints each certificate and its details-->
  <?php foreach ($certificatedetailsList as $certificatedetails) : ?>
    <div class="flex-parent-element">
      <div class="flex-child-element">
          <!--11/18/22 A.Flores NEW 11L: implemented certificate edit and delete button -->
        <div class='buttonstyle'>
          <br><a href="index.php?certificatedetails/edit?id=<?= $certificatedetails->id ?>">
            <input type="button" value="Edit" style="width: 97px; height: 47px; font-size: 18px;"></a>
        </div>
        <div class='buttonstyle'>
          <form action="index.php?certificatedetails/delete" method="post">
            <input type="hidden" name="id" value="<?= $certificatedetails->id ?>">
            <input type="submit" value="Delete">
          </form>
        </div>
      </div>
      <div class="flex-child-element2">
        <blockquote>
          <h3><?= (new \Ninja\Markdown($certificatedetails->certificatename))->toHtml() ?></h3>
          <br>
          <h4>Description:</h4><br>
          <?= (new \Ninja\Markdown($certificatedetails->certificatedescription))->toHtml() ?>
          <br>
          <h4>Required Courses (Complete):</h4>
            <!--11/18/22 A.Flores NEW 15L: foreach loop goes through all courses-->
          <?php foreach ($courses as $course) : ?>
              <!--11/18/22 A.Flores NEW 12L: nested foreach loop prints goes through all certificatecourses-->
            <?php foreach ($certificatecourses as $certificatecourse) : ?>
               <!--11/18/22 A.Flores NEW 9L: if $certificatedetails->id matches $certificatecourse->certificateDetailsId and $certificatecourse->requiredcoursesId 
               matches $course->id, then print course details-->
              <?php if ($certificatedetails->id == $certificatecourse->certificateDetailsId && $certificatecourse->requiredcoursesId == $course->id) : ?>
                <br>
                <details>
                  <summary><b><?= htmlspecialchars($course->coursecode, ENT_QUOTES, 'UTF-8'); ?>-
                      <?= htmlspecialchars($course->coursename, ENT_QUOTES, 'UTF-8'); ?>:</b></summary>
                  <?= (new \Ninja\Markdown($course->coursedescription))->toHtml() ?>
                </details>
              <?php endif; ?>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </blockquote>
      </div>
    </div>
  <?php endforeach; ?>
    <!--11/18/22 A.Flores NEW 1L: print total number of certificates-->
  <?php echo $totalCertificates ? 'Select page:' : '' ?>

  <?php
    //11/18/22 A.Flores NEW 1L: compute $numPages
  $numPages = ceil($totalCertificates / 5);
    //11/18/22 A.Flores NEW 8L: for loop prints links for certificate pages
  for ($i = 1; $i <= $numPages; $i++) : ?>
      <!--11/18/22 A.Flores NEW 5L: if page is current page, then set <a> tag with class currentpage. Else do not set class to <a> tag-->
    <?php if ($i == $currentPage) : ?>
      <a class="currentpage" href="index.php?certificatedetails/manage?page=<?= $i ?>"><?= $i ?></a>
    <?php else : ?>
      <a href="index.php?certificatedetails/manage?page=<?= $i ?>" style="padding-left: 5px;">[<?= $i ?>]</a>
    <?php endif; ?>
  <?php endfor; ?><br><br>
     <!--11/18/22 A.Flores NEW 1L: Back to top button to page-->
  <button onclick="topFunction()" id="TopBtn" title="Go to top">Top</button>
</div>