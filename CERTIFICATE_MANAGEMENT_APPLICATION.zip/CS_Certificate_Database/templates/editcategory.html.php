	<!--11/12/22 A.Flores NEW 1L: Implemented breadcrumbs-->
<p class="breadcrumb"><a href="index.php?category/list">Manage Categories</a> &gt; Edit Category</p>
	<!--11/12/22 A.Flores MOD 6L: Change label to fit new context and added tabindexs and accesskeys for inputs in form-->
<form action="" method="post">
	<input type="hidden" name="category[id]" value="<?=$category->id ?? ''?>">
	<label for="categoryname">Enter concentration name:</label>
	<input type="text" id="categoryname" name="category[name]" tabindex="1" accesskey="n" value="<?=$category->name ?? ''?>" required/>
	<input type="submit" name="submit" tabindex="2" accesskey="s" value="Save">
</form>
