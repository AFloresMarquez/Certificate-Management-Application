	<!--10/21/22 A.Flores NEW 1L: added header tag for register page-->
<h2>Computer Science Certificates - Register Form</h2><br>
	<!--11/26/22 A.Flores ORIG 10L: if $error is set, then display errors-->
<?php if (!empty($errors)): ?>
	<div class="errors">
		<p>Your account could not be created, please check the following:</p>
		<ul>
			<!--11/26/22 A.Flores ORIG 3L: foreach-->
		<?php foreach ($errors as $error): ?>
			<li><?= $error ?></li>
		<?php endforeach; 	?>
		</ul>
	</div>
<?php endif; ?>
	<!--11/26/22 A.Flores NEW 16L: added tabindexs and accesskeys for inputs in form-->
<form action="" method="post">
    <label for="email">Your email address</label>
    <input name="user[email]" id="email" type="text" tabindex="1" accesskey="e" value="<?=$user['email'] ?? ''?>">
    
         <!--10/21/22 A.Flores MOD 2L: replace name with first name-->
	<label for="firstname">Your first name</label>
    <input name="user[firstname]" id="firstname" type="text" tabindex="2" accesskey="f" value="<?=$user['firstname'] ?? ''?>">
         <!--10/21/22 A.Flores NEW 2L: added new last name field-->
	<label for="lastname">Your last name</label>
    <input name="user[lastname]" id="lastname" type="text" tabindex="3" accesskey="l" value="<?=$user['lastname'] ?? ''?>">

    <label for="password">Password</label>
    <input name="user[password]" id="password" type="password" tabindex="4" accesskey="p" value="<?=$user['password'] ?? ''?>">
 
    <input type="submit" name="submit" value="Register account" tabindex="5" accesskey="s">
</form>