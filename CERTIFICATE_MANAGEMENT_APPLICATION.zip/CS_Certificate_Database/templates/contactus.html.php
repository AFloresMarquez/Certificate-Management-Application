     <!--10/09/22 A.Flores NEW 27L: created contact page that gives contact info-->
<div class="sectioncentered">
     <h2>Computer Science Certificates - Contact Us</h2>
     <br>
     <p>
     Professor Jozef Goetz Website:
     <a href="http://classes.jgspectrum.com/">http://classes.jgspectrum.com/</a><br>
     University of La Verne Website: 
     <a href="https://laverne.edu/">https://laverne.edu/</a><br><br>
     6001 Rosemead blvd #E,<br>
     Pico Rivera, CA 90660<br>
     Phone Number:
     <a id="mobile" href="tel:888-555-5555"> 888-555-5555</a><br>
     Email:
     <a href="cs.certifcates@cs.com"> cs.certifcates@cs.com</a><br>
          <!--10/09/22 A.Flores NEW 6L: implemented google map div-->
     <div style="overflow:hidden;width: 500px;position: relative; margin: auto;">
          <iframe width="500" height="500" 
          src="https://maps.google.com/maps?width=250&amp;height=250&amp;hl=en&amp;q=6001%20Rosemead%20blvd%20%23E%2C%20Pico%20Rivera%2C%20CA%2090660+(Location)&amp;ie=UTF8&amp;t=&amp;z=11&amp;iwloc=B&amp;output=embed" 
          frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><div style="position: absolute;width: 500px;bottom: 10px;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;text-align: center;">
          <small style="line-height: 1.8;font-size: 2px;background: #fff;">Powered by <a href="https://embedgooglemaps.com/es/">Embedgooglemaps.com/es/</a> & <a href="https://mibew.org/">Web traffic Geeks</a></small></div>
<         <style>#gmap_canvas img{max-width:none!important;background:none!important}</style>
          <!--11/28/22 A.Flores NEW 1L: implemented google calender with <iframe> tag-->
     <br><iframe src="https://calendar.google.com/calendar/embed?src=en.usa%23holiday%40group.v.calendar.google.com&ctz=America%2FLos_Angeles" style="border: 0" width="500" height="500" frameborder="0" scrolling="no"></iframe>
     </div><br/><br>
     <!--10/09/22 A.Flores NEW 7L: implemented social media links-->
     <b>Social Media:</b><br>
     Facebook:
     <a href="https://www.facebook.com/">https://www.facebook.com/</a><br>
     Twitter:
     <a href="https://twitter.com/">https://twitter.com/</a><br>
     Instagram:
     <a href="https://www.instagram.com/">https://www.instagram.com/</a><br>
     </p>
</div>