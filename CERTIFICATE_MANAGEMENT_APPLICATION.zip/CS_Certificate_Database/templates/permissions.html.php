	<!--10/09/22 A.Flores MOD 1L: author changed to user-->
<h2>Edit <?=$user->firstname?> <?=$user->lastname?>'s Permissions</h2>
	<!--11/12/22 A.Flores NEW 1L: Implemented breadcrumbs-->
<br><p class="breadcrumb"><a href="index.php?user/list">Manage Users</a> &gt; Edit User</p>
	<!--11/12/22 A.Flores MOD 10L: Implemented accesskey for submit button-->
<form action="" method="post">
		<!--11/12/22 A.Flores 6L: Use for loop to print each permission. Check permission if user has permission using if statement-->
	<?php foreach ($permissions as $name => $value): ?>
		<div>
			<input name="permissions[]" type="checkbox" value="<?=$value?>" <?php if ($user->hasPermission($value)) echo 'checked'; ?> />
			<label><?=ucwords(strtolower(str_replace('_', ' ', $name)))?>
		</div>
	<?php endforeach; ?>
	<input type="submit" value="Submit" accesskey="s"/>
</form>