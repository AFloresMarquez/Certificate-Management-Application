<h2>You are not logged in</h2>
		<!--10/09/22 A.Flores MOD 2L: author changed to user-->
	<p>You must be logged in to view this page. <a href="index.php?login">Click here to log in</a> or 
	<a href="index.php?user/register">Click here to register an account</a></p> 