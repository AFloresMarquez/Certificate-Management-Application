	<!--10/15/22 A.Flores NEW 1L: Inserted responsive image-->
<img src="aboutus.jpg" alt="About Us Image by Shahid Abdullah from Pixabay" class="responsiveimage">
<h2>Computer Science Certificates - About Us</h2>
<br>
<h2>About us </h2>
    <p>Computer Science Certificate is a web application of computer science certificates and reicipents. Explore the website to view
    information about certificates and the list of reicipents. 
	We are dedicated to provide the best expereince for this platform so our visitors can come out with having a great expereince. 
	Creating this platform can help those who are searching for computer science certificates available at the Univeristy of La Verne to improve their resume.</p>
<h2>Goals </h2>
    <p>Our purpose and main goal is to provide a platform where students or school facutly can view infromation about computer science certificates and reicipents of those certificates.
	To provide an easy to use website that uses a clear navigation and provide the ability for the user to create a secure account
	to manage and track certificates or reicipents who receive certificates. We want our users to feel comfortable and safe while navigating on this website</p>
<h2>Mission Statement & Values</h2>
  <p>Our vision is to create a place where individuals can view information about computer science certificates. 
   Our mission is to help spread awareness and inspiration for students to receive certificates. We value professionals and people who have interest in computer science certificates.</p>