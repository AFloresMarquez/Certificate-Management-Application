	<!--11/26/22 A.Flores MOD 6L: Added tabindexs and accesskeys for inputs in form-->
<form action="" method="post">
 	    <!--11/12/22 A.Flores NEW 1L: Implemented breadcrumbs-->   
    <p class="breadcrumb"><a href="index.php?certificatedetails/manage">Manage Certificates</a> &gt; Edit Certificate</p>
    	<!--11/26/22 A.Flores NEW 10L: errorhanding messages using foreach loop shown if there are errors-->
    <?php if (!empty($errors)): ?>
	<div class="errors">
		<p>Form cannot be submitted, please check the following:</p>
		<ul>
            <!--11/26/22 A.Flores NEW 10L: errorhanding messages shown if there are errors. Each error is printed using foreach loop-->
		<?php foreach ($errors as $error): ?>
			<li><?= $error ?></li>
		<?php endforeach; 	?>
		</ul>
	</div>
    <?php endif; ?>
        <!--10/22/22 A.Flores NEW 1L: send hidden id value certificatedetails[id]-->
	<input type="hidden" name="certificatedetails[id]" value="<?=$certificatedetails->id ?? ''?>">
	   	<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit certificate name-->
    <label for="certificatename">Type certificate name here:</label>
    <textarea id="certificatename" name="certificatedetails[certificatename]" tabindex="1" accesskey="n" rows="3" cols="40"><?=$certificatedetails->certificatename ?? ''?></textarea>
	   	<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit certificate description-->
	<label for="certificatedescription">Type certificate description here:</label>
    <textarea id="certificatedescription" name="certificatedetails[certificatedescription]" tabindex="2" accesskey="d" rows="3" cols="40"><?=$certificatedetails->certificatedescription ?? ''?></textarea>
        <!--10/22/22 A.Flores MOD 11L: changed checkboxs to select tag to select courses-->   
    <p>Select the required courses for this certificate:<br>
    Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.</p>
    <select name="course[]" multiple style="width: auto;" tabindex="3" accesskey="c">
        <!--11/27/22 A.Flores NEW 8L: foreach loop prints courses options-->   
    <?php foreach ($courses as $course): ?>
            <!--11/27/22 A.Flores MOD 11L: if certificatedetails is set and has courses, then add option that is selected. Else do not select added option-->   
        <?php if ( $certificatedetails && $certificatedetails->hasRequiredCourses($course->id)): ?>
            <option value="<?=$course->id?>"  selected><?=$course->coursecode?>: <?=$course->coursename?></option>
        <?php else: ?>
            <option value="<?=$course->id?>"><?=$course->coursecode?>: <?=$course->coursename?></option>
        <?php endif; ?>
    <?php endforeach; ?>
    </select>
    <input type="submit" name="submit" tabindex="4" accesskey="s" value="Save">
</form>