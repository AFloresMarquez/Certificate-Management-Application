  <!--11/17/22 A.Flores NEW 1L: Added title header to page-->
<h2>Computer Science Certificates - Manage Categories</h2><br>

<!-- <a href="/category/edit">Add a new category</a> JG 6/3/18 org-->
<!--  <a href="index.php?category/edit">Add a new category</a>  6/3/18 JG MOD1L and moved to layout.html.php-->
  <!--11/8/22 A.Flores NEW 2L: Added add button to add categories-->
<a href="index.php?category/edit">
  <input type="button" value="Add" style="width: 100px; height: 45px; font-size: 18px; margin-left: 10px; float: none;"></a><br>
   <!--11/8/22 A.Flores MOD 13L: foreach loop to print each categories and buttons-->
<?php foreach($categories as $category): ?>
<div class='buttonstyle'> <!--11/17/22 A.Flores MOD 4L: insert button into div with class buttonstyle-->
  <a href="index.php?category/edit?id=<?=$category->id?>">
  <input type="button" value="Edit" style="width: 100px; height: 45px; font-size: 18px;"></a>
</div>
 <div class='buttonstyle'> <!--11/17/22 A.Flores MOD 4L: insert button into div with class buttonstyle-->
    <form action="index.php?category/delete" method="post"> 
      <input type="hidden" name="id" value="<?=$category->id?>">
      <input type="submit" value="Delete" >
    </form></div>
  <div class='buttonstyle'> 
  <p>
  <?=htmlspecialchars($category->name, ENT_QUOTES, 'UTF-8')?>
  </p></div>
<br>
<?php endforeach; ?></p>
