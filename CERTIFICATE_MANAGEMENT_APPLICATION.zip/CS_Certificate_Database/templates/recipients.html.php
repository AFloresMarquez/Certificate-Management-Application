  <!--11/17/22 A.Flores NEW 1L: Added title header to page-->
<h2>Computer Science Certificates - Recipients List</h2><br>
  <!--11/17/22 A.Flores MOD 1L: replace jokelist with list-->
<div class="list">
  
  <ul class="categories">
    <h3 style="color: white;">Concentration</h3><br>
    <?php foreach ($categories as $category) : ?>
      <li><a href="index.php?certificate/list?category=<?= $category->id ?>"><?= $category->name ?></a></li> <!--  6/3/18 JG MOD1L -->
    <?php endforeach; ?>
    <br>
    <h3 style="color: white;">Certificates</h3><br>
      <!--11/17/22 A.Flores NEW 3L: foreach loop prints each link to filter using certificatedetails id-->
    <?php foreach ($certificatedetails as $certificatedetail) : ?>
      <li><a href="index.php?certificate/list?certificatedetail=<?= $certificatedetail->id ?>"><?= $certificatedetail->certificatename ?></a></li>
    <?php endforeach; ?>
    <br>
      <!--11/17/22 A.Flores NEW 1L: link to clear filter-->
    <li><a href="index.php?certificate/list">Clear Filter</a></li>
  </ul>
    <!--11/17/22 A.Flores MOD 1L: replace joke with recipient-->
  <div class="recipient">
        <!--11/17/22 A.Flores MOD 1L: replace $totalJokes with $totalRecipients-->
    <p style="padding: 15px;"><?= $totalRecipients ?> recipients have been submitted to the CS Certificate Database.</p><br>
    <div>
        <!--11/17/22 A.Flores MOD 68L: Results of recipients are display in a table-->
      <table>
          <!--11/17/22 A.Flores NEW 12L: set up table headers-->
        <thead>
          <tr>
            <th scope="col">Functions</th>
            <th scope="col">Student First Name</th>
            <th scope="col">Student Last Name</th>
            <th scope="col">Major</th>
            <th scope="col">Concentration</th>
            <th scope="col">Certificate Name</th>
            <th scope="col">Date of Completion</th>
            <th scope="col">User</th>
          </tr>
        </thead>
        <tbody>
            <!--11/17/22 A.Flores MOD 1L: replace $jokes with $certificates-->
          <?php foreach ($certificates as $certificate) : ?>
            <tr>
              <td data-label="Functions"><br>
                  <!--11/17/22 A.Flores MOD 15L: replace $author with $user and $jokes with $certificates-->
                <?php if ($user) : ?>
                    <!--11/18/22 A.Flores NEW 7L: checks if recipient belongs to user or if user has permission to edit. If one is turn, then print edit button-->
                  <?php if ($user->id == $certificate->userId || $user->hasPermission(\Csdb\Entity\User::EDIT_RECIPIENTS)) : ?>
                    <!--  <a href="/joke/edit?id=<//?=$joke->id?>">Edit</a> JG 6/3/18 org-->
                    <br><a href="index.php?certificate/edit?id=<?= $certificate->id ?>">
                      <!-- JG 5/25/18 MOD2L -->
                      <input type="button" value="Edit" style="width: 82px; height: 35px; font-size: 16px;">
                    </a>
                  <?php endif; ?>
                    <!--11/18/22 A.Flores NEW 7L: checks if recipient belongs to user or if user has permission to delete. If one is turn, then print delete button-->
                  <?php if ($user->id == $certificate->userId || $user->hasPermission(\Csdb\Entity\User::DELETE_RECIPIENTS)) : ?>
                    <!--  <form action="/joke/delete" method="post"> JG 6/3/18 org-->
                    <form action="index.php?certificate/delete" method="post">
                      <!-- / 6/3/18 JG MOD1L -->
                      <input type="hidden" name="id" value="<?= $certificate->id ?>">
                      <input type="submit" value="Delete">
                    </form>
                </td>
            <?php endif; ?>
          <?php endif; ?>
            <!--11/17/22 A.Flores MOD 6L: $joke with $certificate and each field will be displayed in a table data cell-->
          <td data-label="Student First Name"><?= (new \Ninja\Markdown($certificate->studfname))->toHtml() ?></td>
          <td data-label="Student Last Name"><?= (new \Ninja\Markdown($certificate->studlname))->toHtml() ?></td>
          <td data-label="Major"><?= (new \Ninja\Markdown($certificate->major))->toHtml() ?></td>
          <td data-label="Concentration"><?= (new \Ninja\Markdown($certificate->concentration))->toHtml() ?></td>
          <td data-label="Certificate Name"><?= (new \Ninja\Markdown($certificate->getCertificatedetails()->certificatename))->toHtml() ?></td>
          <td data-label="Date of Completion">
              <!--11/17/22 A.Flores MOD 18L: replace $author with $user and $joke with $certificate-->
            <?php 
              $datecomplete = new DateTime($certificate->certificatecomplete);
              echo $datecomplete->format('m-d-y'); ?></td>
              <td data-label="User"> by <a href="mailto:<?= htmlspecialchars(
                  $certificate->getUser()->email, ENT_QUOTES, 'UTF-8'); ?>">
              <?= htmlspecialchars(
                $certificate->getUser()->firstname,
                ENT_QUOTES,
                'UTF-8'
              ); ?>
              <?= htmlspecialchars(
                $certificate->getUser()->lastname,
                ENT_QUOTES,
                'UTF-8'
              ); ?></a> on
            <?php
            $date = new DateTime($certificate->certificatedate);
            echo $date->format('jS F Y'); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
        <!--11/18/22 A.Flores MOD 1L: changed $totalJokes to $totalRecipients-->
      <?php echo $totalRecipients ? 'Select page:' : '' ?>
      <!--  6/8/18 JG NEW 1L Improve: don't display 'Select page' if no jokes -->
              
      <?php
        //11/18/22 A.Flores MOD 1L: changed $totalJokes to $totalRecipients
      $numPages = ceil($totalRecipients / 10);
        //11/18/22 A.Flores NEW 8L: for loop prints links for each recipient pages
      for ($i = 1; $i <= $numPages; $i++) :
          //11/18/22 A.Flores NEW 9L: if $check equals 1 then filter page using $categoryId
        if ($check == 1) :
      ?>
            <!--11/18/22 A.Flores NEW 5L: if page is current page, then set <a> tag with class currentpage. Else do not set class to <a> tag-->
          <?php if ($i == $currentPage) : ?>
            <a class="currentpage" href="index.php?certificate/list?page=<?= $i ?><?= !empty($categoryId) ? '&category=' . $categoryId : '' ?>"><?= $i ?></a> <!--  6/3/18 JG MOD1L -->
          <?php else : ?>
            <a href="index.php?certificate/list?page=<?= $i ?><?= !empty($categoryId) ? '&category=' . $categoryId : '' ?>"><?= $i ?></a> <!--  6/3/18 JG MOD1L -->
          <?php endif; ?>
        <?php endif; ?>
          <!--11/18/22 A.Flores NEW 8L: if $check equals 2 then filter page using $certificatedetailsId-->
        <?php if ($check == 2) : ?>
            <!--11/18/22 A.Flores NEW 4L: if page is current page, then set <a> tag with class currentpage. Else do not set class to <a> tag-->
          <?php if ($i == $currentPage) : ?>
            <a class="currentpage" href="index.php?certificate/list?page=<?= $i ?><?= !empty($certificatedetailsId) ? '&certificatedetail=' . $certificatedetailsId : '' ?>"><?= $i ?></a>
          <?php else : ?>
            <a href="index.php?certificate/list?page=<?= $i ?><?= !empty($certificatedetailsId) ? '&certificatedetail=' . $certificatedetailsId : '' ?>"><?= $i ?></a>
          <?php endif; ?>
        <?php endif; ?>
      <?php endfor; ?><br><br>
         <!--11/18/22 A.Flores NEW 1L: Back to top button to page-->
      <button onclick="topFunction()" id="TopBtn" title="Go to top">Top</button>
  </div>
</div>