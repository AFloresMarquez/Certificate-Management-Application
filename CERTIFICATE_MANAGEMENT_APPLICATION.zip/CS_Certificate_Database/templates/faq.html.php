	<!--10/15/22 A.Flores NEW 1L: Inserted responsive image-->
	<img src="faq.jpg" alt="FAQ Image by Louis from Pixabay" class="responsiveimage">
	<h2>Computer Science Certificates - FAQ</h2>
	<br>
	<details>
		<summary>How can I add a certificate into the list of certificates?</summary>
		<p>User with permissions will be able to add certificates into the system.</p>
	</details><br>
	<details>
		<summary>How can I add reicipents to the list of reicipents?</summary>
		<p>User with permissions will be able to add reicipents into the system.</p>
	</details><br>
	<details>
		<summary>Will the database be continually updated?</summary>
		<p>Yes, we are continually updating our database.</p>
	</details>
	<details>
		<summary>Where can I view the list of reicipents?</summary>
		<p>You can find the list of reicipents on the Reicipents List page.</p>
	</details><br>
	<details>
		<summary>Where can I view the list of certificates?</summary>
		<p>You can find the list of certificates on the Certificate page.</p>
	</details>