  <!--11/17/22 A.Flores NEW 1L: Added title header to page-->
<h2>Computer Science Certificates - Manage Courses</h2><br>
<div class="list">
     <!--11/18/22 A.Flores NEW 2L: Added add button to add certificates-->
  <br><a href="index.php?requiredcourses/edit">
    <input type="button" value="Add" style="width: 100px; height: 45px; font-size: 18px; margin-left: 8px; float: none;"></a><br>
      <!--11/18/22 A.Flores NEW 35L: foreach loop goes through all courses-->
  <?php foreach ($courses as $course) : ?>
    <div class="flex-parent-element">
      <div class="flex-child-element">
          <!--11/18/22 A.Flores NEW 11L: implemented course edit and delete button -->
        <div class='buttonstyle'>
          <br><a href="index.php?requiredcourses/edit?id=<?= $course->id ?>">
            <input type="button" value="Edit" style="width: 97px; height: 47px; font-size: 18px;"></a>
        </div>
        <div class='buttonstyle'>
          <form action="index.php?requiredcourses/delete" method="post">
            <input type="hidden" name="id" value="<?= $course->id ?>">
            <input type="submit" value="Delete">
          </form>
        </div>
      </div>
      <div class="flex-child-element2">
        <blockquote>
          <h3><b><?= htmlspecialchars($course->coursecode, ENT_QUOTES, 'UTF-8'); ?> -
              <?= htmlspecialchars($course->coursename, ENT_QUOTES, 'UTF-8'); ?>:</b></h3><br><br>
          <h4>Description:</h4>
          <?= (new \Ninja\Markdown($course->coursedescription))->toHtml() ?>
          <h3>Certificates:</h3><br>
          <ul>
              <!--11/18/22 A.Flores NEW 17L: foreach loop goes through all $certificateDetails-->
            <?php foreach ($certificateDetailsList as $certificateDetails) : ?>
              <?php foreach ($certificatecourses as $certificatecourse) : ?>
                <!--11/18/22 A.Flores NEW 11L: if $certificatedetails->id matches $certificatecourse->certificateDetailsId and $certificatecourse->requiredcoursesId 
              matches $course->id, then print course details-->
                <?php if ($certificateDetails->id == $certificatecourse->certificateDetailsId && $certificatecourse->requiredcoursesId == $course->id) : ?>
                  <br>
                  <li><?= htmlspecialchars($certificateDetails->certificatename, ENT_QUOTES, 'UTF-8'); ?><br></li>
                <?php endif; ?>
              <?php endforeach; ?>
            <?php endforeach; ?>
          </ul>
        </blockquote>
      </div>
    </div>
  <?php endforeach; ?>
    <!--11/18/22 A.Flores NEW 1L: print total number of certificates-->
  <?php echo $totalCourses ? 'Select page:' : '' ?>

  <?php
    //11/18/22 A.Flores NEW 1L: compute $numPages
  $numPages = ceil($totalCourses / 5);
    //11/18/22 A.Flores NEW 8L: for loop prints links for certificate pages
  for ($i = 1; $i <= $numPages; $i++) : ?>
      <!--11/18/22 A.Flores NEW 5L: if page is current page, then set <a> tag with class currentpage. Else do not set class to <a> tag-->
    <?php if ($i == $currentPage) : ?>
      <a class="currentpage" href="index.php?requiredcourses/manage?page=<?= $i ?>"><?= $i ?></a>
    <?php else : ?>
      <a href="index.php?requiredcourses/manage?page=<?= $i ?>" style="padding-left: 5px;">[<?= $i ?>]</a>
    <?php endif; ?>
  <?php endfor; ?><br><br>
     <!--11/18/22 A.Flores NEW 1L: Back to top button to page-->
  <button onclick="topFunction()" id="TopBtn" title="Go to top">Top</button>
</div>