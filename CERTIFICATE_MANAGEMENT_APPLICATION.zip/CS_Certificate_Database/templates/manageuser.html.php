  <!--11/17/22 A.Flores NEW 1L: Added title header to page-->
<h2>Computer Science Certificates - Manage Users</h2><br>

<table>
	<thead>
		<th>First Name</th> <!--11/17/22 A.Flores MOD 1L: name change to first name-->
		<th>Last Name</th>	<!--11/17/22 A.Flores NEW 1L: added table heading last name-->
		<th>Email</th>
		<th>Edit</th>
	</thead>

	<tbody> <!--11/17/22 A.Flores MOD 8L: added data label for each td tag in foreach loop-->
		<?php foreach ($users as $user): ?>
		<tr>
			<td data-label="First Name"><?=$user->firstname;?></td>	
			<td data-label="Last Name"><?=$user->lastname;?></td>	
			<td data-label="Email"><?=$user->email;?></td>
			<td data-label="Edit"><a href="index.php?user/permissions?id=<?=$user->id;?>">Edit Permissions</a></td> <!-- JG 6/3/18 MOD1L -->
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>


