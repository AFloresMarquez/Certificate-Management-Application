<form action="" method="post">
        <!--10/22/22 A.Flores NEW 1L: send hidden id value courses[id]-->
	<input type="hidden" name="courses[id]" value="<?=$courses->id ?? ''?>">
	    <!--11/12/22 A.Flores NEW 1L: Implemented breadcrumbs-->   
    <p class="breadcrumb"><a href="index.php?requiredcourses/manage">Manage Courses</a> &gt; Edit Course</p>
	    <!--11/26/22 A.Flores NEW 10L: errorhanding messages shown if there are errors. Each error is printed using foreach loop-->
    <?php if (!empty($errors)): ?>
	<div class="errors">
		<p>Form cannot be submitted, please check the following:</p>
		<ul>
		<?php foreach ($errors as $error): ?>
			<li><?= $error ?></li>
		<?php endforeach; 	?>
		</ul>
	</div>
    <?php endif; ?>
    	<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit course code-->
    <label for="coursecode">Type course code here:</label>
    <input type="text" id="coursecode" name="courses[coursecode]" tabindex="1" accesskey="c" placeholder="CCCC 999" value="<?=$courses->coursecode ?? ''?>">
		<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit course name-->
	<label for="coursename">Type course name here:</label>
    <textarea id="coursename" name="courses[coursename]" tabindex="2" accesskey="n" rows="3" cols="40"><?=$courses->coursename ?? ''?></textarea>
        <!--10/22/22 A.Flores NEW 2L: allow user to enter or edit course description-->
    <label for="coursedescription">Type course description here:</label>
    <textarea id="coursedescription" name="courses[coursedescription]" tabindex="3" accesskey="d" rows="3" cols="40"><?=$courses->coursedescription ?? ''?></textarea>

        <!--11/27/22 A.Flores MOD 13L: changed checkboxs to select tag to select certificates-->  
    <p>Select the certificates that requires this course:<br>
    Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.</p>
    <select name="certificatedetail[]" multiple style="width: auto;" tabindex="1" accesskey="v">
        <!--10/22/22 A.Flores NEW 11L: foreach loop prints option for each certificate-->
    <?php foreach ($certificateDetailsList as $certificateDetails): ?>
            <!--10/22/22 A.Flores NEW 5L: if course is set and has a certificate, then add option that is selected. Else do not select  added option-->
        <?php if ($courses && $courses->hasCertificateDetails($certificateDetails->id)):?>
            <option value="<?=$certificateDetails->id?>"  selected><?=$certificateDetails->certificatename?></option>
        <?php else: ?>
            <option value="<?=$certificateDetails->id?>"><?=$certificateDetails->certificatename?></option>
        <?php endif; ?>
    <?php endforeach; ?>
    </select>
    <input type="submit" name="submit" value="Save" tabindex="5" accesskey="s">
</form>