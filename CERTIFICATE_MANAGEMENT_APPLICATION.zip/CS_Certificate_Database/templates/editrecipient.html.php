	<!--10/09/22 A.Flores MOD 64L: author changed to user and joke to certificate-->
    <!--10/09/22 A.Flores MOD 64L: if user has permission to edit, then they can edit recipient-->
<?php if (empty($certificate->id) || $user->id == $certificate->userId || $user->hasPermission(\Csdb\Entity\User::EDIT_RECIPIENTS)): ?>
<form action="" method="post">
        <!--10/22/22 A.Flores NEW 1L: send hidden id value certificate[id]-->
	<input type="hidden" name="certificate[id]" value="<?=$certificate->id ?? ''?>">
	    <!--11/12/22 A.Flores NEW 1L: Implemented breadcrumbs-->   
    <p class="breadcrumb"><a href="index.php?certificate/manage">Manage Recipients</a> &gt; Edit Recipient</p>
        <!--11/26/22 A.Flores NEW 10L: errorhanding messages shown if there are errors-->
    <?php if (!empty($errors)): ?>
	<div class="errors">
		<p>Form cannot be submitted, please check the following:</p>
		<ul>
		    <?php foreach ($errors as $error): ?>
			    <li><?= $error ?></li>
		    <?php endforeach; 	?>
		</ul>
	</div>
    <?php endif; ?>
    	<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit student first name-->
    <label for="studfname">Type recipient's first name here:</label>
    <textarea id="studfname" name="certificate[studfname]" tabindex="1" accesskey="f" rows="3" cols="40"><?=$certificate->studfname ?? ''?></textarea>
		<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit student last name-->
	<label for="studlname">Type recipient's last name here:</label>
    <textarea id="studlname" name="certificate[studlname]" tabindex="2" accesskey="l" rows="3" cols="40"><?=$certificate->studlname ?? ''?></textarea>
	
		<!--10/22/22 A.Flores NEW 4L: use radio button to select major-->
	<p>Select the major for this recipient:</p>
	
    <input type="radio" id="major" checked name="certificate[major]" tabindex="3" accesskey="m" value="Computer Science"/> 
	<label for="major">Computer Science</label><br>
		<!--10/22/22 A.Flores NEW 2L: allow user to enter or edit date of completion-->
	<br><label for="certificatecomplete">Enter date of certificate completion:</label>
    <input type="date" id="certificatecomplete" name="certificate[certificatecomplete]" tabindex="4" accesskey="d" value="<?=$certificate->certificatecomplete?>" required>
	    <!--10/22/22 A.Flores NEW 10L: allow user to enter or edit recipient's concentration-->
    <p tabindex="5">Select the concentration for this recipient:</p>
        <!--10/22/22 A.Flores NEW 10L: foreach loop prints radio button for each concentration-->
    <?php foreach ($categories as $category): ?>
            <!--10/22/22 A.Flores MOD 5L: if certificate has category assigned to it, then check radio button. Else don't check radio button-->
        <?php if ($certificate && $certificate->hasCategory($category->id)): ?>
            <input type="radio" checked name="category[]" value="<?=$category->id?>" required/> 
        <?php else: ?>
            <input type="radio" name="category[]" value="<?=$category->id?>" required/> 
        <?php endif; ?>
	
	    <label><?=$category->name?></label>
	<?php endforeach; ?>

	    <!--10/22/22 A.Flores NEW 10L: allow user to enter or edit recipient's certificate-->
	<p tabindex="6">Select the certificate received by the recipient:</p>
        <!--10/22/22 A.Flores NEW 11L: foreach loop prints radio button for each certificate-->
    <?php foreach ($certificatedetails as $certificatedetail): ?>
            <!--10/22/22 A.Flores MOD 5L: if reicipent has certificate, then check radio button. Else don't check radio button-->
        <?php if ( $certificate && $certificatedetail->id == $certificate->certificatedetailsId): ?>
            <input type="radio" checked name="certificate[certificatedetailsId]" value="<?=$certificatedetail->id?>" required/> 
        <?php else: ?>
            <input type="radio" name="certificate[certificatedetailsId]" value="<?=$certificatedetail->id?>" required/> 
        <?php endif; ?>

        <label><?=$certificatedetail->certificatename?></label> <br>

    <?php endforeach; ?>
    <input type="submit" name="submit" value="Save" style="margin-top: 10px;" tabindex="7" accesskey="s">
</form>
<?php else: ?><!--10/09/22 A.Flores MOD 5L: else user cannot edit recipient-->

<p>You may only edit recipients that you posted.</p>

<?php endif; ?> 