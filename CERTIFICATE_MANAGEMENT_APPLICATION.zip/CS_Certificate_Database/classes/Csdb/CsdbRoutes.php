<?php
namespace Csdb;//11/12/22 A.Flores MOD 1L: use namespace Csdb
	//11/12/22 A.Flores MOD 1L: IjdbRoutes changed to CsdbRoutes
class CsdbRoutes implements \Ninja\Routes {
	private $usersTable; //11/12/22 A.Flores MOD 1L: changed $authorsTable to $usersTable
	private $certificatesTable; //11/12/22 A.Flores MOD 1L: changed $jokesTable to $certificatesTable
	private $categoriesTable;
	private $certificateCategoriesTable; //11/12/22 A.Flores MOD 1L: changed $jokeCategoriesTable to $certificateCategoriesTable
	private $certificateDetailsTable;  //11/12/22 A.Flores NEW 1L: added $certificateDetailsTable variable
	private $requiredCoursesTable; //11/12/22 A.Flores NEW 1L: added $requiredCoursesTable variable 
	private $certificateRequiredCoursesTable; //11/12/22 A.Flores NEW 1L: added $certificateRequiredCoursesTable variable
	private $authentication;

	public function __construct() {
		include __DIR__ . '/../../includes/DatabaseConnection.php';
			//11/12/22 A.Flores MOD 1L: replaced jokessTable with certificatesTable, authorsTable with usersTable, and jokeCategoriesTable with certificateCategoriesTable
		$this->certificatesTable = new \Ninja\DatabaseTable($pdo, 'certificate', 'id', '\Csdb\Entity\Certificate', [&$this->usersTable, &$this->certificateCategoriesTable, &$this->certificateDetailsTable, &$this->categoriesTable]);//
 			//11/12/22 A.Flores MOD 1L: replaced authorsTable with usersTable and jokesTable with certificatesTable
		$this->usersTable = new \Ninja\DatabaseTable($pdo, 'user', 'id', '\Csdb\Entity\User', [&$this->certificatesTable]);
			//11/12/22 A.Flores MOD 1L: replaced joke with certificate
 		$this->categoriesTable = new \Ninja\DatabaseTable($pdo, 'category', 'id', '\Csdb\Entity\Category', [&$this->certificatesTable, &$this->certificateCategoriesTable]);
			//11/12/22 A.Flores NEW 1L: initialize new table objects
		$this->certificateDetailsTable = new \Ninja\DatabaseTable($pdo, 'certificatedetails', 'id', '\Csdb\Entity\Certificatedetails', [&$this->requiredCoursesTable, &$this->certificateDetailsTable, &$this->certificateRequiredCoursesTable, &$this->certificatesTable]);
		$this->requiredCoursesTable = new \Ninja\DatabaseTable($pdo, 'requiredcourses', 'id', '\Csdb\Entity\Requiredcourses', [&$this->certificateDetailsTable, &$this->certificateRequiredCoursesTable]);
		$this->certificateRequiredCoursesTable = new \Ninja\DatabaseTable($pdo, 'certificaterequiredcourses', 'certificateDetailsId');
			//11/12/22 A.Flores MOD 1L: jokeCategoriesTable with certificateCategoriesTable
		$this->certificateCategoriesTable = new \Ninja\DatabaseTable($pdo, 'certificatecategory', 'categoryId');
		$this->authentication = new \Ninja\Authentication($this->usersTable, 'email', 'password');
	}

	public function getRoutes(): array {
			//11/12/22 A.Flores MOD 2L: replaced joke with certificate and added $this->certificateDetailsTable in parameters. 
		$certificateController = new \Csdb\Controllers\Certificate($this->certificatesTable, $this->usersTable, $this->categoriesTable, 
            $this->certificateCategoriesTable, $this->certificateDetailsTable, $this->authentication); // 6/12/18 JG MOD 1L: added $jokeCategoriesTable to manipulate it e.g. delete a child table
			//11/12/22 A.Flores MOD 1L: replaced author with user
		$userController = new \Csdb\Controllers\Register($this->usersTable);
		$loginController = new \Csdb\Controllers\Login($this->authentication);
			//11/12/22 A.Flores MOD 1L: replaced jokeCategoriesTable with certificateCategoriesTable
        $categoryController = new \Csdb\Controllers\Category($this->categoriesTable, $this->certificateCategoriesTable);  // 6/12/18 JG NEW 1L 2 arguments for deletion the child table
			//11/12/22 A.Flores NEW 1L: implemented new controller $certificateDetailsController 
		$certificateDetailsController = new \Csdb\Controllers\Certificatedetails($this->usersTable, $this->certificateDetailsTable, $this->requiredCoursesTable, $this->certificateRequiredCoursesTable, $this->authentication); 
			//11/12/22 A.Flores NEW 1L: implemented new controller $requiredCoursesController
		$requiredCoursesController = new \Csdb\Controllers\Requiredcourses($this->certificateDetailsTable, $this->requiredCoursesTable, $this->usersTable, $this->authentication, $this->certificateRequiredCoursesTable); 
		
		$routes = [ //10/10/22 A.Flores MOD 10L: replaced author with user.
			'user/register' => [
				'GET' => [
					'controller' => $userController,
					'action' => 'registrationForm'
				],
				'POST' => [
					'controller' => $userController,
					'action' => 'registerUser'
				]
			],	//10/10/22 A.Flores MOD 6L: replaced author with user.
			'user/success' => [
				'GET' => [
					'controller' => $userController,
					'action' => 'success'
				]
			], //10/10/22 A.Flores MOD 12L: replaced author with user.
			'user/permissions' => [
				'GET' => [
					'controller' => $userController,
					'action' => 'permissions'
				],
				'POST' => [
					'controller' => $userController,
					'action' => 'savePermissions'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_USER_ACCESS  // JG required
			], //10/10/22 A.Flores MOD 8L: replaced author with user.
			'user/list' => [
				'GET' => [
					'controller' => $userController,
					'action' => 'list'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_USER_ACCESS
			], //10/10/22 A.Flores MOD 11L: replaced joke with certificate.
			'certificate/edit' => [
				'POST' => [
					'controller' => $certificateController,
					'action' => 'saveEdit'
				],
				'GET' => [
					'controller' => $certificateController,
					'action' => 'edit'
				],
				'login' => true
			],	//10/10/22 A.Flores MOD 6L: replaced joke with certificate.
			'certificate/delete' => [
				'POST' => [
					'controller' => $certificateController,
					'action' => 'delete'
				],
				'login' => true
			],	//10/10/22 A.Flores MOD 6L: replaced joke with certificate.
			'certificate/list' => [
				'GET' => [
					'controller' => $certificateController,
					'action' => 'list'
				]
			],
				//10/31/22 A.Flores NEW 7L: added route to Manage Recipient page. Requires login.
			'certificate/manage' => [
				'GET' => [
					'controller' => $certificateController,
					'action' => 'manage'
				],
				'login' => true,
			],
			     //10/10/22 A.Flores NEW 6L: added route to About Us page
			'certificate/aboutus' => [
				'GET' => [
					'controller' => $certificateController,
					'action' => 'aboutUs'
				]
			],
			     //10/10/22 A.Flores NEW 6L: added route to Contact page
			'certificate/contactus' => [
				'GET' => [
					'controller' => $certificateController,
					'action' => 'contactUs'
				]
			],
			     //10/10/22 A.Flores NEW 4L: added route to FAQ page
			'certificate/faq' => [
				'GET' => [
					'controller' => $certificateController,
					'action' => 'faq'
				]
			],
			'login/error' => [
				'GET' => [
					'controller' => $loginController,
					'action' => 'error'
				]
			],
			'login/permissionserror' => [
				'GET' => [
					'controller' => $loginController,
					'action' => 'permissionsError'
				]
			],
			'login/success' => [
				'GET' => [
					'controller' => $loginController,
					'action' => 'success'
				]
			],
			'logout' => [
				'GET' => [
					'controller' => $loginController,
					'action' => 'logout'
				]
			],
			'login' => [
				'GET' => [
					'controller' => $loginController,
					'action' => 'loginForm'
				],
				'POST' => [
					'controller' => $loginController,
					'action' => 'processLogin'
				]
			],
			'category/edit' => [
				'POST' => [
					'controller' => $categoryController,
					'action' => 'saveEdit'
				],
				'GET' => [
					'controller' => $categoryController,
					'action' => 'edit'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES  // JG required
			],
			'category/delete' => [
				'POST' => [
					'controller' => $categoryController,
					'action' => 'delete'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::REMOVE_CATEGORIES
			],
			'category/list' => [
				'GET' => [
					'controller' => $categoryController,
					'action' => 'list'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES
			],
				//11/05/22 A.Flores NEW 12L: added route to edit certificate details. Requires permissions  and login.
			'certificatedetails/edit' => [
				'POST' => [
					'controller' => $certificateDetailsController,
					'action' => 'saveEdit'
				],
				'GET' => [
					'controller' => $certificateDetailsController,
					'action' => 'edit'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES
			],
				//11/05/22 A.Flores NEW 8L: added route to delete certificate details. Requires permissions and login.
			'certificatedetails/delete' => [
				'POST' => [
					'controller' => $certificateDetailsController,
					'action' => 'delete'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::REMOVE_CATEGORIES
			],
				//11/05/22 A.Flores NEW 6L: added route to list certificates.
			'certificatedetails/list' => [
				'GET' => [
					'controller' => $certificateDetailsController,
					'action' => 'list'
				]
			],
				//11/05/22 A.Flores NEW 8L: added route to manage certificates. Requires permissions and login.
			'certificatedetails/manage' => [
				'GET' => [
					'controller' => $certificateDetailsController,
					'action' => 'manage'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES
			],
			     //11/05/22 A.Flores NEW 12L: added route to edit course. Requires permissions and login.
			'requiredcourses/edit' => [
				'POST' => [
					'controller' => $requiredCoursesController,
					'action' => 'saveEdit'
				],
				'GET' => [
					'controller' => $requiredCoursesController,
					'action' => 'edit'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES
			],
			     //11/05/22 A.Flores NEW 8L: added route to delete course. Requires permissions and login.
			'requiredcourses/delete' => [
				'POST' => [
					'controller' => $requiredCoursesController,
					'action' => 'delete'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::REMOVE_CATEGORIES
			],
			     //11/05/22 A.Flores NEW 8L: added route to manage courses. Requires permissions and login.
			'requiredcourses/manage' => [
				'GET' => [
					'controller' => $requiredCoursesController,
					'action' => 'manage'
				],
				'login' => true,
				'permissions' => \Csdb\Entity\User::EDIT_CATEGORIES
			],
			'' => [ //10/10/22 A.Flores MOD 5L: replaced $jokeController with $certificateController
				'GET' => [
					'controller' => $certificateController,
					'action' => 'home'
				]
			]
		];

		return $routes;
	}

	public function getAuthentication(): \Ninja\Authentication {   
		return $this->authentication;
	}
	
	public function checkPermission($permission): bool {  // p.591
		$user = $this->authentication->getUser();
           print ('IjdbRoutes.php: checkPermission($permission) L:171 the highest single permission = ' . $permission . '<br>'); //5/16/22 JG
		   
		if ($user && $user->hasPermission($permission)) {
			return true;
		} else {
			return false;
		}
	}

}