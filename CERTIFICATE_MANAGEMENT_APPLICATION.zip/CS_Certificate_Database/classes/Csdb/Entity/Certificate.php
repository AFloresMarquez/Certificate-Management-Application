<?php
namespace Csdb\Entity;//10/28/22 A.Flores MOD 1L: use Csdb instead of Ijdb
	//10/28/22 A.Flores MOD 59L: class definition for Certificate 
class Certificate {
	public $id;
	public $userId; //10/28/22 A.Flores MOD 1L: changed authorId to userId
	public $studfname; //10/28/22 A.Flores NEW 1L: declare $studfname variable
	public $studlname;  //10/28/22 A.Flores NEW 1L: declare $studlname variable
	public $major;	//10/28/22 A.Flores NEW 1L: declare  $major variable
	public $concentration;   //10/28/22 A.Flores NEW 1L: declare $concentration variable
	public $certificatedate; 
	public $certificatecomplete;   //10/28/22 A.Flores NEW 1L: declare $certificatecomplete variable
	public $certificatedetailsId;	//10/28/22 A.Flores NEW 1L: declare $concentration variable
	private $usersTable; //10/28/22 A.Flores MOD 1L: changed authorsTable to usersTable
	private $user;	//10/28/22 A.Flores MOD 1L: changed author to user
	private $certificateCategoriesTable; //10/28/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
	private $categoriesTable;    //10/28/22 A.Flores NEW 1L: declare $categoriesTable variable
	private $certificateDetailsTable;    //10/28/22 A.Flores NEW 1L: declare $certificateDetailsTable variable
	private $certificatedetails;    //10/28/22 A.Flores NEW 1L: declare $certificatedetails variable
		//10/28/22 A.Flores MOD 6L: repalce $authorsTable with $usersTable and $jokeCategoriesTable with $certificateCategoriesTable and added new table objects $certificateDetailsTable and $categoriesTable 
	public function __construct(\Ninja\DatabaseTable $usersTable, \Ninja\DatabaseTable $certificateCategoriesTable, \Ninja\DatabaseTable $certificateDetailsTable, \Ninja\DatabaseTable $categoriesTable) {
		$this->usersTable = $usersTable;
		$this->certificateCategoriesTable = $certificateCategoriesTable;
		$this->certificateDetailsTable = $certificateDetailsTable;
		$this->categoriesTable = $categoriesTable;
	}
			//10/28/22 A.Flores MOD 6L: replaced author with user
	public function getUser() {
		if (empty($this->user)) {
			$this->user = $this->usersTable->findById($this->userId);
		}
		
		return $this->user;
	}
		//10/28/22 A.Flores NEW 4L: getCertificatedetails() function gets certificatedetails objects using certificatedetailsId and return it 
	public function getCertificatedetails() {
		
		return $this->certificatedetails = $this->certificateDetailsTable->findById($this->certificatedetailsId);
	}

	public function addCategory($categoryId) {
			//10/28/22 A.Flores MOD 1L: replaced joke with certificate
		$certificateCat = ['certificateId' => $this->id, 'categoryId' => $categoryId];
			//10/28/22 A.Flores MOD 1L: replaced jokeCategoriesTable with certificateCategoriesTable
		$this->certificateCategoriesTable->save($certificateCat);
	}
			//10/28/22 A.Flores MOD 9L: replaced jokeCategoriesTable with certificateCategoriesTable
	public function hasCategory($categoryId) {
		$certificateCategories = $this->certificateCategoriesTable->find('certificateId', $this->id);

		foreach ($certificateCategories as $certificateCategory) {
			if ($certificateCategory->categoryId == $categoryId) {
				return true;
			}
		}
	}
 
	public function clearCategories() {
			//10/28/22 A.Flores MOD 1L: replaced jokeCategoriesTable with certificateCategoriesTable
		$this->certificateCategoriesTable->deleteWhere('certificateId', $this->id);
	}
}