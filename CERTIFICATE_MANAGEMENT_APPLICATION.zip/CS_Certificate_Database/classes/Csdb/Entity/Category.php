<?php
namespace Csdb\Entity;//10/09/22 A.Flores MOD 1L: changed Ijdb to Csdb

use Ninja\DatabaseTable;

class Category {
	public $id;
	public $name;
	private $certificatesTable;//10/09/22 A.Flores MOD 1L: changed jokesTable to certificatesTable
	private $certificateCategoriesTable;//10/09/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
		//10/09/22 A.Flores MOD 44L: changed any references of joke changed to certificate
	public function __construct(DatabaseTable $certificatesTable, DatabaseTable $certificateCategoriesTable) {
		$this->certificatesTable = $certificatesTable;
		$this->certificateCategoriesTable = $certificateCategoriesTable;
	}
		//11/12/22 A.Flores MOD 16L: changed jokes to certificates
	public function getCertificates($limit = null, $offset = null) {
		$certificateCategories = $this->certificateCategoriesTable->find('categoryId', $this->id, null, $limit, $offset);
        print ('Category.php: getJokes($limit, $offset)L19 id = ' .$this->id. '<br>');  // test
		print ('Category.php: getJokes($limit, $offset)L20 limit = ' .$limit. '<br>');  // test
		print ('Category.php: getJokes($limit, $offset)L21 offset = ' .$offset. '<br>');  // test
		
		$certificates = [];

		foreach ($certificateCategories as $certificateCategory) {
			$certificate =  $this->certificatesTable->findById($certificateCategory->certificateId);
			
			if ($certificate) {
				$certificates[] = $certificate;
			}			
		}

		usort($certificates, [$this, 'sortCertificates']);

		return $certificates;
	}
		//11/12/22 A.Flores MOD 3L: changed jokes to certificates
	public function getNumCertificates() {
		return $this->certificateCategoriesTable->total('categoryId', $this->id);
	}
	
	public function getCategoryName() {
		return name;}
	
		//11/12/22 A.Flores MOD 16L: changed jokes to certificates
	private function sortCertificates($a, $b) {
		$aDate = new \DateTime($a->certificatedate);
		$bDate = new \DateTime($b->certificatedate);

		if ($aDate->getTimestamp() == $bDate->getTimestamp()) {
			return 0;
		}

		return $aDate->getTimestamp() < $bDate->getTimestamp() ? -1 : 1;
	}
}