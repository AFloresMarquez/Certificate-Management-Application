<?php
namespace Csdb\Entity;//11/12/22 A.Flores NEW 1L: use namespace Csdb\Entity
	//11/12/22 A.Flores NEW 85L: class definition for Certificatedetails 
class Certificatedetails {
		//11/12/22 A.Flores NEW 9L: declare public and private class variables
	public $id;
	public $certificatename;
	public $certificatedescription;
	private $requiredCoursesTable;
	private $certificateDetailsTable;
	private $requiredcourses;
	private $certificateRequiredCoursesTable;
	private $certificatesTable;
		//11/12/22 A.Flores NEW 6L: constructor for class Certificatedetails. Initializes DatabaseTable objects
	public function __construct(\Ninja\DatabaseTable $requiredCoursesTable, \Ninja\DatabaseTable $certificateDetailsTable, \Ninja\DatabaseTable $certificateRequiredCoursesTable, \Ninja\DatabaseTable $certificatesTable) {
		$this->requiredCoursesTable = $requiredCoursesTable;
		$this->certificateDetailsTable = $certificateDetailsTable;
		$this->certificateRequiredCoursesTable = $certificateRequiredCoursesTable;
		$this->certificatesTable = $certificatesTable;
	}

		//11/12/22 A.Flores NEW 7L: getRequiredcourses() function gets requiredcourses object and return it 
	public function getRequiredcourses() {
			//11/12/22 A.Flores NEW 3L: if $this->requiredcourses is empty, then find $this->requiredcourses using certificatedetails object id
		if (empty($this->requiredcourses)) {
			$this->requiredcourses = $this->requiredCoursesTable->findById('certificatedetailsId', $this->id);
		}
		return $this->requiredcourses;
	}
		//11/12/22 A.Flores NEW 3L: clearRequiredCourses() function calls deleteWhere() function and removes corresponding record in certificateRequiredCoursesTable.
	public function clearRequiredCourses(){
		$this->certificateRequiredCoursesTable->deleteWhere('certificateDetailsId', $this->id);
	}
		//11/12/22 A.Flores NEW 4L: addRequiredCourses() function takes $requiredcoursesId and assigns certificate to a course.
	public function addRequiredCourses($requiredcoursesId){
			$courseAssign = ['certificateDetailsId' => $this->id, 'requiredcoursesId' => $requiredcoursesId];
			$this->certificateRequiredCoursesTable->save($courseAssign);
	}
		//11/12/22 A.Flores NEW 10L: hasRequiredCourses() function takes in $requiredcoursesId and checks if course has certificates assign to it.
	public function hasRequiredCourses($requiredcoursesId) {
		$certificateRequiredCourses = $this->certificateRequiredCoursesTable->find('certificateDetailsId', $this->id);
			//11/12/22 A.Flores NEW 6L: foreach loop goes through every $certificateRequiredCourses as $certificateRequiredCourse to check if course has certificates assign to it.
		foreach ($certificateRequiredCourses as $certificateRequiredCourse) {
				//11/12/22 A.Flores NEW 3L: if $certificateRequiredCourse->requiredcoursesId equals to $requiredcoursesId, then return true 
			if ($certificateRequiredCourse->requiredcoursesId == $requiredcoursesId) {
				return true;
			}
		}
	}
		//11/12/22 A.Flores NEW 11L: getCertificates() function get certificates and returns certificates 
	public function getCertificates($limit = null, $offset = null) {
			//11/12/22 A.Flores NEW 1L: find recipients with certificateDetailsId using certificateDetails id
		$recipients =  $this->certificatesTable->find('certificateDetailsId', $this->id, null, $limit, $offset);
        print ('Certificatedetails.php: getCertificates($limit, $offset)L19 id = ' .$this->id. '<br>');  // test
		print ('Certificatedetails.php: getCertificates($limit, $offset)L20 limit = ' .$limit. '<br>');  // test
		print ('Certificatedetails.php: getCertificates($limit, $offset)L21 offset = ' .$offset. '<br>');  // test
			//11/12/22 A.Flores NEW 1L: initializes certificates array
		$certificates = [];
			//11/12/22 A.Flores NEW 6L: foreach loop adds recipients to array
		foreach ($recipients as $recipient) {
				//11/12/22 A.Flores NEW 3L: if $recipient has a matching certificatedetailsId to id, then add to array 
			if ($recipient->certificatedetailsId == $this->id) {
				$certificates[] = $recipient;
			}			
		}
			//11/12/22 A.Flores NEW 1L: call sortCertificates() 
		usort($certificates, [$this, 'sortCertificates']);
			//11/12/22 A.Flores NEW 1L: returns certificates 
		return $certificates;
	}
		//11/12/22 A.Flores NEW 3L: returns total number of records in certificatesTable 
	public function getNumCertificates() {
		return $this->certificatesTable->total('certificatedetailsId', $this->id);
	}
	
		//11/12/22 A.Flores NEW 11L: function sortCertificates() sorts certificates using date
	private function sortCertificates($a, $b) {
			//11/12/22 A.Flores NEW 2L: declares and initializes variables of DateTime    
		$aDate = new \DateTime($a->certificatedate);
		$bDate = new \DateTime($b->certificatedate);
			//11/12/22 A.Flores NEW 3L: if timestamp of $aDate is equal to $bDate, then return 0
		if ($aDate->getTimestamp() == $bDate->getTimestamp()) {
			return 0;
		}
				//11/12/22 A.Flores NEW 1L: return timestamp 
		return $aDate->getTimestamp() < $bDate->getTimestamp() ? -1 : 1;
	}
}