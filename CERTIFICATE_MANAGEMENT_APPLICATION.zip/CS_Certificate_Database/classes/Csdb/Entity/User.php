<?php
namespace Csdb\Entity; //10/09/22 A.Flores MOD 1L: changed Ijdb to Csdb

class User {

	const EDIT_RECIPIENTS = 1;//11/12/22 A.Flores MOD 1L: changed jokes to recipients
	const DELETE_RECIPIENTS = 2;//11/12/22 A.Flores MOD 1L: changed jokes to recipients
	const ADD_CATEGORIES = 4;
	const EDIT_CATEGORIES = 8;
	const REMOVE_CATEGORIES = 16;
	const EDIT_USER_ACCESS = 32;

	public $id;
	public $firstname; //10/09/22 A.Flores MOD 1L: changed name to firstname
	public $lastname; //10/09/22 A.Flores NEW 1L: added lastname variable
	public $email;
	public $password;
	
		//10/09/22 A.Flores MOD 23L: changed joke to certificate
	public function __construct(\Ninja\DatabaseTable $certificateTable) {
		$this->certificatesTable = $certificateTable;
	}
		//11/12/22 A.Flores MOD 3L: changed jokes to certificates
	public function getCertificates() {
		return $this->certificatesTable->find('userId', $this->id);
	}
		//11/12/22 A.Flores MOD 7L: changed jokes to certificates
	public function addCertificate($certificate) {
		$certificate['userId'] = $this->id;

           //print ('user.php: addCertificate($certificate) L:30 $certificate[userId] = ' . $certificate['certificateId']. '<br>'); //5/16/22 JG

		return $this->certificatesTable->save($certificate);
	}

	public function hasPermission($permission) {
		
		//print ('Author.php: hasPermission($permission) L:37 $permission = ' . $permission . '<br>'); //5/16/22 JG - deactivate checkboxes in permission list
		
		return $this->permissions & $permission;  
	}
}