<?php
	//11/12/22 A.Flores NEW 1L: use namespace Csdb\Entity
namespace Csdb\Entity;
	//11/12/22 A.Flores NEW 35L: class definition for Requiredcourses
class Requiredcourses {
		//11/12/22 A.Flores NEW 6L: declare variables
	public $id;
	public $coursename;
	public $coursecode;
	public $coursedescription;
	private $certificateDetailsTable;
	private $certificateRequiredCoursesTable; 
		//11/12/22 A.Flores NEW 4L: constructor for class Requiredcourses. Initializes DatabaseTable objects
	public function __construct(\Ninja\DatabaseTable $certificateDetailsTable, \Ninja\DatabaseTable $certificateRequiredCoursesTable) {
		$this->certificateDetailsTable = $certificateDetailsTable;
		$this->certificateRequiredCoursesTable = $certificateRequiredCoursesTable;
	}
		//11/12/22 A.Flores NEW 4L: addCertificatedetails() function takes $certificateDetailsId and assigns course to a certificate.  
	public function addCertificatedetails($certificateDetailsId){ 
		$certificateAssign = ['certificateDetailsId' => $certificateDetailsId, 'requiredcoursesId' => $this->id];
		$this->certificateRequiredCoursesTable->save($certificateAssign);
	}
		//11/12/22 A.Flores NEW 3L: clearCertificateDetails() function calls deleteWhere() function and removes corresponding record in certificateRequiredCoursesTable.
	public function clearCertificateDetails(){
		$this->certificateRequiredCoursesTable->deleteWhere('requiredcoursesId', $this->id);
	}
		//11/12/22 A.Flores NEW 11L: hasCertificateDetails() function takes in $certificateDetailsId and checks if course has certificates assign to it.
	public function hasCertificateDetails($certificateDetailsId) {
		$certificateRequiredCourses = $this->certificateRequiredCoursesTable->find('requiredcoursesId', $this->id);
			//11/12/22 A.Flores NEW 5L: foreach loop goes through every $certificateRequiredCourses as $certificateRequiredCourse to check if course has certificates assign to it. 
		foreach ($certificateRequiredCourses as $certificateRequiredCourse) {
				//11/12/22 A.Flores NEW 3L: if $certificateRequiredCourse->certificateDetailsId equals to $certificateDetailsId, then return true
			if ($certificateRequiredCourse->certificateDetailsId == $certificateDetailsId) {
				return true;
			}
		}
	}
	
}