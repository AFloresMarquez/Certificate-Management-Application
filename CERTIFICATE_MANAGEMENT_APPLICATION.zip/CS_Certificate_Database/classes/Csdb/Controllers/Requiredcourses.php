<?php
	//11/12/22 A.Flores NEW 3L: use namespace Csdb\Entity and use \Ninja\DatabaseTable and \Ninja\Authentication
namespace Csdb\Controllers;
use \Ninja\DatabaseTable;
use \Ninja\Authentication;

class Requiredcourses{
		//11/12/22 A.Flores NEW 5L: declare variables
	private $certificateDetailsTable;
	private $requiredCoursesTable;
	private $certificateRequiredCoursesTable;
	private $usersTable;
	private $authentication;
		//11/12/22 A.Flores NEW 7L: constructor for class Requiredcourses. Initializes DatabaseTable objects
	public function __construct(DatabaseTable $certificateDetailsTable,DatabaseTable $requiredCoursesTable, DatabaseTable $usersTable, Authentication $authentication, DatabaseTable $certificateRequiredCoursesTable){
		$this->certificateDetailsTable = $certificateDetailsTable;
		$this->requiredCoursesTable = $requiredCoursesTable;
		$this->usersTable = $usersTable;
		$this->authentication = $authentication;
		$this->certificateRequiredCoursesTable = $certificateRequiredCoursesTable;
	}
		//11/12/22 A.Flores NEW 27L: function manage() sets up and displays manage course page
	public function manage() {
			//11/12/22 A.Flores NEW 1L: set page number with $_GET['page'] or 1.
		$page = $_GET['page'] ?? 1;
			//11/12/22 A.Flores NEW 1L: compute $offset
		$offset = ($page-1)*5;
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable.
		$certificateDetailsList = $this->certificateDetailsTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateRequiredCoursesTable.
		$certificatecourses = $this->certificateRequiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from requiredCoursesTable.
		$courses = $this->requiredCoursesTable->findAll('coursecode ASC', 5, $offset);
			//11/12/22 A.Flores NEW 1L: call function total() to get total number of records from requiredCoursesTable.
		$totalCourses = $this->requiredCoursesTable->total();

		$title = 'Manage Courses';
             //11/12/22 A.Flores NEW 10L: return  manage courses template, title, and variables needed for page.
		return ['template' => 'managecourses.html.php', 
				'title' => $title,
				'variables' => [
						'certificateDetailsList' => $certificateDetailsList,
						'certificatecourses' => $certificatecourses,
						'courses' => $courses,
						'totalCourses' => $totalCourses,
						'currentPage' => $page
					]
				];
	}
		//11/12/22 A.Flores NEW 8L: function delete() allows user to delete courses on manage courses page 
	public function delete() {
			//11/12/22 A.Flores NEW 1L: first DELETE all rows with $_POST['id'] related to certificateRequiredCoursesTable
		$this->certificateRequiredCoursesTable->deleteWhere('requiredcoursesId', $_POST['id']);
			//11/12/22 A.Flores NEW 1L: delete course using $_POST['id'] sent from the form. 
		$this->requiredCoursesTable->delete($_POST['id']);
			//11/12/22 A.Flores NEW 1L: send user to manage courses page
        header('location: index.php?requiredcourses/manage'); 
	}
		//11/12/22 A.Flores NEW 56L: function saveEdit() saves edit of course
	public function saveEdit() {
		$course = $_POST['courses'];
		$certificateDetailsList = $this->certificateDetailsTable->findAll();
		
			//11/12/22 A.Flores NEW 1L: Assume the data is valid to begin with
		$valid = true;
		$errors = [];
			//11/12/22 A.Flores NEW 4L: if course code does not match pattern, then set $valid to false and add error message to error array.
		if (!preg_match( "/^[A-Z]{3,4} [0-9]{3}$/", $course['coursecode'])) {
			$valid = false;
			$errors[] = 'Course code cannot be blank and must be in the correct format: CMPS 999 or CMP 999';
		}
			//11/12/22 A.Flores NEW 4L: if course name is blank, then set $valid to false and add error message to error array.
		if (trim($course['coursename']) =='') {
			$valid = false;
			$errors[] = 'Course name cannot be blank';
		}
			//11/12/22 A.Flores NEW 4L: if course description is blank, then set $valid to false and add error message to error array.
		if (trim($course['coursedescription']) =='') {
			$valid = false;
			$errors[] = 'Course description cannot be blank';
		}
	
			//11/12/22 A.Flores NEW 12L: if $valid is true, then save edit of course.
		if ($valid == true) {
		
			$requiredcoursesObject = $this->requiredCoursesTable->save($course);
				//11/12/22 A.Flores NEW 1L: call clearCertificateDetails() to clear certificates assign to course.
			$requiredcoursesObject->clearCertificateDetails();
				//11/12/22 A.Flores NEW 3L: foreach loop assigns certificates to course using addCertificateDetails() function.
			foreach ($_POST['certificatedetail'] as $certificateDetailsId) {
				$requiredcoursesObject->addCertificateDetails($certificateDetailsId);
			}
				//11/12/22 A.Flores NEW 1L: return user to manage course page.
			header('location: index.php?requiredcourses/manage'); 
		}
		else{
				//11/12/22 A.Flores NEW 6L: if $_GET['id'] is set, then find and get records from requiredCoursesTable using $_GET['id']. Else $courses is null. 
			if (isset($_GET['id'])) {
				$courses = $this->requiredCoursesTable->findById($_GET['id']); 
			}
			else{
				$courses = null;
			}
				//11/12/22 A.Flores NEW 9L: If the data is not valid, show the form again
			return ['template' => 'editrequiredcourse.html.php', 
				    'title' => 'Edit Course',
				    'variables' => [
				    	'errors' => $errors,
				    	'courses' => $courses ?? null,
						'certificateDetailsList' => $certificateDetailsList
				    ]
				   ]; 
		}

	}
		//11/12/22 A.Flores NEW 18L: function edit() allows the user to edit courses on the website using a form
	public function edit() {
			//11/12/22 A.Flores NEW 3L: if $_GET['id'] is set, then find courses using id from requiredCoursesTable
		if (isset($_GET['id'])) {
			$courses = $this->requiredCoursesTable->findById($_GET['id']);
		}
			//11/12/22 A.Flores NEW 1L: get all records from certificateDetailsTable and store into $certificateDetailsList as objects. 
		$certificateDetailsList = $this->certificateDetailsTable->findAll();

		$title = 'Edit Course';
			//11/12/22 A.Flores NEW 7L: returns edit template, title, $courses or null, and $certificateDetailsList 
		return ['template' => 'editrequiredcourse.html.php',
				'title' => $title,
				'variables' => [
					'courses' => $courses ?? null,
					'certificateDetailsList' => $certificateDetailsList
					]
				];
	}
	
}
	
