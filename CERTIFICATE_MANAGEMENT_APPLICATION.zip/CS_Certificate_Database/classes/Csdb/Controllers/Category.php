<?php
namespace Csdb\Controllers;	//10/09/22 A.Flores MOD 1L: changed Ijdb to Csdb

class Category {
	private $categoriesTable;
    private $certificateCategoriesTable; //10/09/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
	
	//public function __construct(\Ninja\DatabaseTable $categoriesTable) {
	    //$this->categoriesTable = $categoriesTable;   //6/9/18 JG DEL 1L:
	public function __construct(\Ninja\DatabaseTable $categoriesTable, \Ninja\DatabaseTable $certificateCategoriesTable) { 
		$this->categoriesTable = $categoriesTable;
		$this->certificateCategoriesTable = $certificateCategoriesTable; //10/09/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
	}

	public function edit() {

		if (isset($_GET['id'])) {
			$category = $this->categoriesTable->findById($_GET['id']);
		}

		$title = 'Edit Category';

		return ['template' => 'editcategory.html.php',
				'title' => $title,
				'variables' => [
					'category' => $category ?? null
				]
		];
	}

	public function saveEdit() {
		$category = $_POST['category'];

		$this->categoriesTable->save($category);

		// header('location: /category/list'); 6/7/18 JG DEL 1L: org
		header('location: index.php?category/list');  // 6/7/18 JG NEW 1L: 
	}

	public function list() {
		$categories = $this->categoriesTable->findAll();
			//10/09/22 A.Flores MOD 1L: changed joke to certificate
		$title = 'Certificate Categories';
			//10/09/22 A.Flores MOD 1L: changed categories to managecategories
		return ['template' => 'managecategories.html.php', 
			'title' => $title, 
			'variables' => [
			    'categories' => $categories
			  ]
		];
	}
	
	
	public function delete() {
		$this->certificateCategoriesTable->delete($_POST['id']); //10/09/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
		$this->categoriesTable->delete($_POST['id']);  // 6/9/18 JG Delete a row at the parent table

		// header('location: /category/list'); 6/7/18 JG DEL 1L: org
		header('location: index.php?category/list');  // 6/7/18 JG NEW 1L: 
	}
}