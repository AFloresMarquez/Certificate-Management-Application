<?php
namespace Csdb\Controllers;//10/28/22 A.Flores MOD 1L: use Csdb instead of Ijdb
use \Ninja\DatabaseTable;
use \Ninja\Authentication;
	//10/28/22 A.Flores MOD 1L: renamed class Joke to Certificate 
class Certificate {
	private $usersTable; //10/28/22 A.Flores MOD 1L: changed authorsTable to usersTable
	private $certificatesTable; //10/28/22 A.Flores MOD 1L: changed jokesTable to certificatesTable
	private $categoriesTable;
	private $certificateCategoriesTable; //10/28/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
	private $certificateDetailsTable; //10/28/22 A.Flores NEW 1L: declare $certificateDetailsTable variable
	private $authentication;

		//10/28/22 A.Flores MOD 9L: replaced entire contructor parameters with new variables for DatabaseTable and Authentication objects  
	public function __construct(DatabaseTable $certificatesTable, DatabaseTable $usersTable, DatabaseTable $categoriesTable, 
	     DatabaseTable $certificateCategoriesTable, DatabaseTable $certificateDetailsTable, Authentication $authentication) { //6/12/18 JG MOD 1L: added $jokeCategories table to manipulate it e.g. delete a child table
    	$this->certificatesTable = $certificatesTable; //10/28/22 A.Flores MOD 1L: changed jokesTable to certificatesTable
		$this->usersTable = $usersTable;  //10/28/22 A.Flores MOD 1L: changed authorsTable to usersTable
		$this->categoriesTable = $categoriesTable;
		$this->certificateCategoriesTable = $certificateCategoriesTable; //10/28/22 A.Flores MOD 1L: changed jokeCategoriesTable to certificateCategoriesTable
		$this->certificateDetailsTable = $certificateDetailsTable; //10/28/22 A.Flores NEW 1L: declare $certificateDetailsTable variable
		$this->authentication = $authentication;
	}

	public function list() {

		$page = $_GET['page'] ?? 1;

		$offset = ($page-1)*10;

		if (isset($_GET['category'])) {
			$category = $this->categoriesTable->findById($_GET['category']);
			$certificates = $category->getCertificates(10, $offset); //10/28/22 A.Flores MOD 1L: replace jokes with certificates
			$totalRecipients = $category->getNumCertificates(); //10/28/22 A.Flores MOD 1L: replace jokes with recipients and getNumJokes() with getNumCertificates()
			$certificatedetails = $this->certificateDetailsTable->findAll(); //10/28/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable. 
			$check = 1; //10/28/22 A.Flores NEW 1L: set check to 1 to use correct page links 
		}	//10/28/22 A.Flores NEW 7L: else if $_GET['certificatedetail'] is set, then filter page and recipients using $certificatedetail. Not $category
		elseif (isset($_GET['certificatedetail'])) {
			$certificatedetail = $this->certificateDetailsTable->findById($_GET['certificatedetail']);
			$certificates = $certificatedetail->getCertificates(10, $offset);
			$totalRecipients = $certificatedetail->getNumCertificates(); 	
			$certificatedetails = $this->certificateDetailsTable->findAll();
			$check = 2; //10/28/22 A.Flores NEW 1L: set check to 2 to use correct page links
		}
		else {
			$certificates = $this->certificatesTable->findAll('certificatedate DESC', 10, $offset);
			$totalRecipients = $this->certificatesTable->total(); 	//10/28/22 A.Flores MOD 1L: replace jokes with recipients 
			$certificatedetails = $this->certificateDetailsTable->findAll(); 
			$check = 1; //10/28/22 A.Flores NEW 1L: set check to 1 to use correct page links 
		}		
			//10/28/22 A.Flores MOD 1L: replace joke with recipient 
		$title = 'Recipient list';

		$user = $this->authentication->getUser();
				//10/28/22 A.Flores MOD 1L: replace jokes with recipients 
		return ['template' => 'recipients.html.php', 
				'title' => $title, 
				'variables' => [
						'totalRecipients' => $totalRecipients, 	//10/28/22 A.Flores MOD 1L: replace jokes with recipients 
						'certificates' => $certificates, 	//10/28/22 A.Flores MOD 1L: replace jokes with recipients 
						'user' => $user, //10/28/22 A.Flores MOD 1L: replaced $author with $user
						'categories' => $this->categoriesTable->findAll(),
						'currentPage' => $page,
						'categoryId' => $_GET['category'] ?? null,
						'certificatedetails' => $certificatedetails,  //10/28/22 A.Flores NEW 1L: pass $certificatedetails to list recipient page
						'certificatedetailsId' => $_GET['certificatedetail'] ?? null, 	//10/28/22 A.Flores NEW 1L: pass $_GET['certificatedetail'] or null to list recipient page
						'check' => $check   //10/28/22 A.Flores NEW 1L: pass $check to list recipient page
					]
				];
		
	}

	public function home() {
			//10/10/22 A.Flores MOD 1L: changed title to Computer Science Certificates 
		$title = 'Computer Science Certificates';

		return ['template' => 'home.html.php', 'title' => $title];
	}
	
	 //10/10/22 A.Flores NEW 5L: added aboutUS() method to display About Us page
	public function aboutUS() {
		$title = 'About Us';
             //10/10/22 A.Flores NEW 1L: return About Us template and title 
		return ['template' => 'aboutus.html.php', 'title' => $title];
	}
	     //10/10/22 A.Flores NEW 5L: added contactUS() method to display Contact Us page
	public function contactUs() {
		$title = 'Contact Us';
             //10/10/22 A.Flores NEW 1L: return Contact Us template and title 
		return ['template' => 'contactus.html.php', 'title' => $title];
	}
	    //10/10/22 A.Flores NEW 5L: added contactUS() method to display Contact Us page
	public function faq() {
		$title = 'FAQ';
             //10/10/22 A.Flores NEW 1L: return Contact Us template and title 
		return ['template' => 'faq.html.php', 'title' => $title];
	}
		//10/28/22 A.Flores NEW 46L: function manage() sets up and displays manage recipients page
	public function manage() {
           	//10/28/22 A.Flores NEW 1L: set page number with $_GET['page'] or 1.
		$page = $_GET['page'] ?? 1;
			//10/28/22 A.Flores NEW 1L: compute $offset
		$offset = ($page-1)*10;
			//10/28/22 A.Flores NEW 7L: else if $_GET['category'] is set, then filter page and recipients using $category and set $check to 1. 
		if (isset($_GET['category'])) {
			$category = $this->categoriesTable->findById($_GET['category']);
			$certificates = $category->getCertificates(10, $offset);
			$totalRecipients = $category->getNumCertificates();
			$certificatedetails = $this->certificateDetailsTable->findAll(); 
			$check = 1;
		}	//10/28/22 A.Flores NEW 7L: else if $_GET['certificatedetail'] is set, then filter page and recipients using $certificatedetail. Not $category
		elseif (isset($_GET['certificatedetail'])) {
			$certificatedetail = $this->certificateDetailsTable->findById($_GET['certificatedetail']);
			$certificates = $certificatedetail->getCertificates(10, $offset);
			$totalRecipients = $certificatedetail->getNumCertificates();
			$certificatedetails = $this->certificateDetailsTable->findAll();
			$check = 2;
		}
		else { 	//10/28/22 A.Flores NEW 7L: else don't not use any filter to find recipients
			$certificates = $this->certificatesTable->findAll('certificatedate DESC', 10, $offset);
			$totalRecipients = $this->certificatesTable->total();
			$certificatedetails = $this->certificateDetailsTable->findAll(); 
			$check = 1;
		}		
			//10/28/22 A.Flores NEW 1L: set title
		$title = 'Manage Recipients';

		$user = $this->authentication->getUser();
			//11/12/22 A.Flores NEW 10L: return  manage recipient template, title, and variables needed for page.
		return ['template' => 'managerecipients.html.php', 
				'title' => $title, 
				'variables' => [
						'totalRecipients' => $totalRecipients,
						'certificates' => $certificates,
						'user' => $user,
						'categories' => $this->categoriesTable->findAll(),
						'currentPage' => $page,
						'categoryId' => $_GET['category'] ?? null,
						'certificatedetails' => $certificatedetails,
						'certificatedetailsId' => $_GET['certificatedetail'] ?? null,
						'check' => $check
					]
				];
	}

	
	public function delete() {

		$user = $this->authentication->getUser();
			//10/28/22 A.Flores MOD 4L: replaced joke with certificate and Ijdb with Csdb 
		$certificate = $this->certificatesTable->findById($_POST['id']);

		if ($certificate->userId != $user->id && !$user->hasPermission(\Csdb\Entity\User::DELETE_JOKES) ) {
			return;
		}
			//10/28/22 A.Flores MOD 1L: replaced jokeCategoriesTable with certificateCategoriesTable and jokeid with certificateid
        $this->certificateCategoriesTable->deleteWhere('certificateid', $_POST['id']); // 6/13/18 JG NEW 1L:  first DELETE all rows with $_POST['id'] related to a child table
		                                               //otherwise DB problem and joke display problem for [1] 2 3 etc.
			//10/28/22 A.Flores MOD 1L: changed jokesTable to certificatesTable
		$this->certificatesTable->delete($_POST['id']);   // 6/13/18 JG delete a row at the parent table
		
			//10/28/22 A.Flores MOD 1L: replaced joke with certificate in the route
        header('location: index.php?certificate/list');  // 5/25/18 JG NEW 1L  	

	}

	public function saveEdit() {
		$user = $this->authentication->getUser();
			//10/28/22 A.Flores MOD 2L: replaced joke with certificate 
		$certificate = $_POST['certificate'];
		$certificate['certificatedate'] = new \DateTime();
		$categories = $this->categoriesTable->findAll(); 
			//10/28/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable.
		$certificatedetails = $this->certificateDetailsTable->findAll(); 
		
			//10/28/22 A.Flores NEW 2L: Assume the data is valid to begin with
		$valid = true;
		$errors = [];
			//10/28/22 A.Flores NEW 4L: if 'studfname' is blank, then set $valid to false and add error message to error array.
		if (empty($certificate['studfname'])) {
			$valid = false;
			$errors[] = 'First name cannot be blank';
		}
		     //10/28/22 A.Flores NEW 4L: if 'studlname' is blank, then set $valid to false and add error message to error array.
		if (empty($certificate['studlname'])) {
			$valid = false;
			$errors[] = 'Last Name cannot be blank';
		}
			//10/28/22 A.Flores NEW 12L: if $valid is true, then save edit of certificate.
		if ($valid == true) {
				//10/28/22 A.Flores NEW 1L: declare and initialize $id
			$id = 0;
				//10/28/22 A.Flores NEW 3L: foreach $_POST['category'] as $categoryId set $categoryId to $id
			foreach ($_POST['category'] as $categoryId) {
				$id = $categoryId;
			}
				//10/28/22 A.Flores NEW 2L: give $certificate['concentration'] value using $id
			$categoriesInfo = $this->categoriesTable->findById($id);
			$certificate['concentration'] = $categoriesInfo->name;
					//10/28/22 A.Flores MOD 3L: replace joke with certificate
			$certificateEntity = $user->addCertificate($certificate);

			$certificateEntity->clearCategories();
				//10/28/22 A.Flores NEW 3L: foreach loop assigns category to recipient using addCategory() function.
			foreach ($_POST['category'] as $categoryId) {
				$certificateEntity->addCategory($categoryId);
			}
				//10/28/22 A.Flores MOD 1L: return user to list recipient page.
			header('location: index.php?certificate/list');  //5/25/18 JG NEW 1L  
		}
		else{
				//10/28/22 A.Flores NEW 6L: if $_GET['id'] is set, then find and get records from certificatesTable using $_GET['id']. Else $certificatesTable is null. 
			if (isset($_GET['id'])) {
				$certificate = $this->certificatesTable->findById($_GET['id']);
			}
			else {
				$certificate = null;
			}
				//10/28/22 A.Flores NEW 3L: If the data is not valid, show the form again
			return ['template' => 'editrecipient.html.php', 
				    'title' => 'Edit Recipient',
				    'variables' => [
				    	'errors' => $errors,
				    	'certificate' => $certificate ?? null,
						'user' => $user,
						'categories' => $categories,
						'certificatedetails' => $certificatedetails
				    ]
				   ]; 
		}		
	}

	public function edit() {
		$user = $this->authentication->getUser();
		$categories = $this->categoriesTable->findAll();
			//10/28/22 A.Flores MOD 3L: replaced joke with certificate 
		if (isset($_GET['id'])) {
			$certificate = $this->certificatesTable->findById($_GET['id']);
		}
			//10/28/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable.
		$certificatedetails = $this->certificateDetailsTable->findAll();
			
		$title = 'Edit Recipient';
			//10/28/22 A.Flores MOD 1L: replaced editjoke with editcertificate 
		return ['template' => 'editrecipient.html.php',
				'title' => $title,
				'variables' => [
						'certificate' => $certificate ?? null, //10/28/22 A.Flores MOD 1L: replaced $joke with $certificate
						'user' => $user,
						'categories' => $categories,
						'certificatedetails' => $certificatedetails //10/28/22 A.Flores NEW 1L: pass $certificatedetails to edit recipient page 
					]
				];
	}
	
}