<?php
	//10/09/22 A.Flores MOD 1L: changed Ijdb to Csdb
namespace Csdb\Controllers;
use \Ninja\DatabaseTable;

class Register {
	private $usersTable;//10/09/22 A.Flores MOD 1L: changed author to user
		//10/09/22 A.Flores MOD 3L: changed author to user
	public function __construct(DatabaseTable $usersTable) {
		$this->usersTable = $usersTable;
	}

	public function registrationForm() {
		return ['template' => 'register.html.php', 
				'title' => 'Register an account'];
	}


	public function success() {
		return ['template' => 'registersuccess.html.php', 
			    'title' => 'Registration Successful'];
	}
		//10/09/22 A.Flores MOD 67L: changed author to user
	public function registerUser() {
		$user = $_POST['user'];

		//Assume the data is valid to begin with
		$valid = true;
		$errors = [];

		//But if any of the fields have been left blank, set $valid to false
		     //10/09/22 A.Flores MOD 4L: replace name with first name
		if (empty($user['firstname'])) {
			$valid = false;
			$errors[] = 'First name cannot be blank';
		}
		     //10/09/22 A.Flores NEW 4L: added last name error handling
		if (empty($user['lastname'])) {
			$valid = false;
			$errors[] = 'Last name cannot be blank';
		}
		
		if (empty($user['email'])) {
			$valid = false;
			$errors[] = 'Email cannot be blank';
		}
		else if (filter_var($user['email'], FILTER_VALIDATE_EMAIL) == false) {
			$valid = false;
			$errors[] = 'Invalid email address';
		}
		else { //if the email is not blank and valid:
			//convert the email to lowercase
			$user['email'] = strtolower($user['email']);

			//search for the lowercase version of `$author['email']`
			if (count($this->usersTable->find('email', $user['email'])) > 0) {
				$valid = false;
				$errors[] = 'That email address is already registered';
			}
		}


		if (empty($user['password'])) {
			$valid = false;
			$errors[] = 'Password cannot be blank';
		}

		//If $valid is still true, no fields were blank and the data can be added
		if ($valid == true) {
			//Hash the password before saving it in the database
			$user['password'] = password_hash($user['password'], PASSWORD_DEFAULT);

			//When submitted, the $author variable now contains a lowercase value for email
			//and a hashed password
			$this->usersTable->save($user);

			//header('Location: /author/success'); 5/25/18 JG DEL1L  org
            header('Location: index.php?user/success'); //5/25/18 JG NEW1L  

		}
		else {
			//If the data is not valid, show the form again
			return ['template' => 'register.html.php', 
				    'title' => 'Register an account',
				    'variables' => [
				    	'errors' => $errors,
				    	'user' => $user
				    ]
				   ]; 
		}
	}
		//10/09/22 A.Flores MOD 1oL: changed author to user
	public function list() {
		$users = $this->usersTable->findAll();
			//
		return ['template' => 'manageuser.html.php',
				'title' => 'User List',
				'variables' => [
						'users' => $users
					]
				];
	}
		//10/09/22 A.Flores MOD 14L: changed author to user
	public function permissions() {

		$user = $this->usersTable->findById($_GET['id']);

		$reflected = new \ReflectionClass('\Csdb\Entity\User');
		$constants = $reflected->getConstants();
         
		return ['template' => 'permissions.html.php',
				'title' => 'Edit Permissions',
				'variables' => [
						'user' => $user,
						'permissions' => $constants
					]
				];	
	}
		//10/09/22 A.Flores MOD 15L: changed author to user
	public function savePermissions() {
		$user = [
			'id' => $_GET['id'],
			'permissions' => array_sum($_POST['permissions'] ?? [])
		];
		  print ('Register.php: savePermissions() L:118 id = ' . $user['id'] . '<br>'); //5/16/22 JG
		  print ('Register.php: savePermissions() L:120 permissions = ' . $user['permissions'] . '<br>'); //5/16/22 JG the sum of permissions

      	$this->usersTable->save($user);
		
		  //sleep(30);  //5/16/22 JG to show the print trace above after 30 sec timeout

		//header('location: /author/list');  6/3/18 JG DEL1L  org
		header('location: index.php?user/list');    // 6/3/18 JG MOD1L
	}
}