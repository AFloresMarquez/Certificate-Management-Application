<?php
	//11/12/22 A.Flores NEW 3L: use namespace Csdb\Entity and use \Ninja\DatabaseTable and \Ninja\Authentication
namespace Csdb\Controllers;//
use \Ninja\DatabaseTable;
use \Ninja\Authentication;

class Certificatedetails {
		//11/12/22 A.Flores NEW 5L: declare variables
	private $usersTable;
	private $certificateDetailsTable;
	private $requiredCoursesTable;
	private $certificateRequiredCoursesTable; 
	private $authentication;
		//11/12/22 A.Flores NEW 4L: constructor for class Requiredcourses. Initializes DatabaseTable objects
	public function __construct(DatabaseTable $usersTable, DatabaseTable $certificateDetailsTable, DatabaseTable $requiredCoursesTable, DatabaseTable $certificateRequiredCoursesTable, Authentication $authentication){
		$this->certificateDetailsTable = $certificateDetailsTable;
		$this->usersTable = $usersTable;
		$this->requiredCoursesTable = $requiredCoursesTable;
		$this->certificateRequiredCoursesTable = $certificateRequiredCoursesTable; 
		$this->authentication = $authentication;
	}
		//11/12/22 A.Flores NEW 27L: function list() sets up and displays certificates list page
	public function list() {
			//11/12/22 A.Flores NEW 1L: set page number with $_GET['page'] or 1.
		$page = $_GET['page'] ?? 1;
			//11/12/22 A.Flores NEW 1L: compute $offset
		$offset = ($page-1)*5;
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable.
		$certificatedetailsList = $this->certificateDetailsTable->findAll('certificatename ASC', 5, $offset);
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from requiredCoursesTable.
		$courses = $this->requiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateRequiredCoursesTable.
		$certificatecourses = $this->certificateRequiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function total() to get total number of records from certificateDetailsTable.
		$totalCertificates = $this->certificateDetailsTable->total();
		
		$title = 'Certificates list';
		     //11/12/22 A.Flores NEW 10L: return certificates list template, title, and variables needed for page.
		return ['template' => 'certificates.html.php', 
				'title' => $title, 
				'variables' => [
						'certificatedetailsList' => $certificatedetailsList,
						'courses' => $courses,
						'certificatecourses' => $certificatecourses,
						'totalCertificates' => $totalCertificates,
						'currentPage' => $page
					]
				];
	}
		//11/12/22 A.Flores NEW 27L: function manage() sets up and displays manage certificate page
	public function manage() {
			//11/12/22 A.Flores NEW 1L: set page number with $_GET['page'] or 1.
		$page = $_GET['page'] ?? 1;
			//11/12/22 A.Flores NEW 1L: compute $offset
		$offset = ($page-1)*5;
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateDetailsTable.
		$certificatedetailsList = $this->certificateDetailsTable->findAll('certificatename ASC', 5, $offset);
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from certificateRequiredCoursesTable.
		$certificatecourses = $this->certificateRequiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function findAll() to get records from requiredCoursesTable.
		$courses = $this->requiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: call function total() to get total number of records from certificateDetailsTable.
		$totalCertificates = $this->certificateDetailsTable->total();
		
		$title = 'Manage Certificates';
             //11/12/22 A.Flores NEW 10L: return manage certificates template, title, and variables needed for page.
		return ['template' => 'managecertificates.html.php',
				'title' => $title,
				'variables' => [
						'certificatedetailsList' => $certificatedetailsList,
						'certificatecourses' => $certificatecourses,
						'courses' => $courses,
						'totalCertificates' => $totalCertificates,
						'currentPage' => $page
					]
				];
	}
	
		//11/12/22 A.Flores NEW 8L: function delete() allows user delete certificateDetails record on manage certificates page 
	public function delete() {
			//11/12/22 A.Flores NEW 1L: first DELETE all rows with $_POST['id'] related to certificateRequiredCoursesTable
		$this->certificateRequiredCoursesTable->delete($_POST['id']);
			//11/12/22 A.Flores NEW 1L: delete certificateDetails record using $_POST['id'] sent from the form. 
		$this->certificateDetailsTable->delete($_POST['id']);
			//11/12/22 A.Flores NEW 1L: send user to manage courses page
        header('location: index.php?certificatedetails/manage'); 
	}
			//11/12/22 A.Flores NEW 56L: function saveEdit() saves edit of certificate
	public function saveEdit() {
		$certificatedetails = $_POST['certificatedetails'];
		$courses = $this->requiredCoursesTable->findAll();
			//11/12/22 A.Flores NEW 1L: Assume the data is valid to begin with
		$valid = true;
		$errors = [];
			//11/12/22 A.Flores NEW 4L: if certificate name is blank, then set $valid to false and add error message to error array.
		if (trim($certificatedetails['certificatename']) =='') {
			$valid = false;
			$errors[] = 'Certificate name cannot be blank';
		}
		     //11/12/22 A.Flores NEW 4L: if certificate description is blank, then set $valid to false and add error message to error array.
		if (trim($certificatedetails['certificatedescription']) =='') {
			$valid = false;
			$errors[] = 'Certificate description cannot be blank';
		}
			//11/12/22 A.Flores NEW 12L: if $valid is true, then save edit of certificate.
		if ($valid == true) {
		
			$certificatedetailsObject = $this->certificateDetailsTable->save($certificatedetails);
					//11/12/22 A.Flores NEW 1L: call clearRequiredCourses() to clear courses assign to certificate.
			$certificatedetailsObject->clearRequiredCourses();
				//11/12/22 A.Flores NEW 3L: foreach loop assigns courses to certificate using addRequiredCourses() function.
			foreach ($_POST['course'] as $requiredcoursesId) {
				$certificatedetailsObject->addRequiredCourses($requiredcoursesId);
			}
				//11/12/22 A.Flores NEW 1L: return user to manage certificate page.
			header('location: index.php?certificatedetails/manage');   	
		}
		else {
				//11/12/22 A.Flores NEW 6L: if $_GET['id'] is set, then find and get records from certificateDetailsTable using $_GET['id']. Else $certificatedetails is null. 
			if (isset($_GET['id'])) {
				$certificatedetails = $this->certificateDetailsTable->findById($_GET['id']);}
			else{
				$certificatedetails = null;
			}
				//11/12/22 A.Flores NEW 9L: If the data is not valid, show the form again
			return ['template' => 'editcertificate.html.php', 
				    'title' => 'Edit Certificate',
				    'variables' => [
				    	'errors' => $errors,
				    	'certificatedetails' => $certificatedetails ?? null,
						'courses' => $courses
				    ]
				   ]; 
		}

	}
		//11/12/22 A.Flores NEW 18L: function edit() allows the user to edit a certificateDetails record on the website using a form
	public function edit() {
			//11/12/22 A.Flores NEW 3L: if $_GET['id'] is set, then find certificateDetails record using $_GET['id'] from certificateDetailsTable
		if (isset($_GET['id'])) {
			$certificatedetails = $this->certificateDetailsTable->findById($_GET['id']);
		}
			//11/12/22 A.Flores NEW 1L: get all records from requiredCoursesTable and store into $courses as objects.
		$courses = $this->requiredCoursesTable->findAll();
		$title = 'Edit Certificate';
				//11/12/22 A.Flores NEW 7L: returns edit template, title, $certificatedetails  or null, and $courses
		return ['template' => 'editcertificate.html.php',
				'title' => $title,
				'variables' => [
					'certificatedetails' => $certificatedetails ?? null,
					'courses' => $courses
				]
		];
	}
}