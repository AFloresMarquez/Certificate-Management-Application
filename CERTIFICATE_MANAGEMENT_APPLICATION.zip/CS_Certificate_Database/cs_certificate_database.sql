-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2023 at 09:33 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cs_certificate_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Artificial Intelligence'),
(2, 'Engineering'),
(3, 'Information Science'),
(4, 'Internet Programming'),
(5, 'Software');

-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL,
  `studfname` varchar(255) NOT NULL,
  `studlname` varchar(255) NOT NULL,
  `major` varchar(255) NOT NULL,
  `concentration` varchar(255) NOT NULL,
  `certificatedate` date NOT NULL,
  `certificatecomplete` date NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `certificatedetailsId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificate`
--

INSERT INTO `certificate` (`id`, `studfname`, `studlname`, `major`, `concentration`, `certificatedate`, `certificatecomplete`, `userId`, `certificatedetailsId`) VALUES
(1, 'Antonio', 'Flores', 'Computer Science', 'Internet Programming', '2022-09-07', '2022-05-26', 1, 1),
(2, 'Antonio ', 'Flores', 'Computer Science', 'Internet Programming', '2022-12-05', '2022-05-26', 6, 4),
(3, 'Sammy', 'Davis', 'Computer Science', 'Software', '2022-09-07', '2022-05-26', 2, 1),
(4, 'Clara', 'Williams', 'Computer Science', 'Software', '2022-09-07', '2022-05-28', 2, 1),
(5, 'Chloe', 'Smith', 'Computer Science', 'Information Science', '2022-09-07', '2022-05-28', 4, 3),
(7, 'Dave', 'House', 'Computer Science', 'Artificial Intelligence', '2022-12-04', '2022-05-26', 6, 4),
(11, 'Jayce ', 'Donny', 'Computer Science', 'Engineering', '2022-12-04', '2022-05-28', 6, 2),
(12, 'Kason ', 'Penny', 'Computer Science', 'Engineering', '2022-12-04', '2022-05-26', 6, 2),
(13, 'Theodora', 'Hill', 'Computer Science', 'Engineering', '2022-12-04', '2022-05-26', 6, 2),
(14, 'Jake', 'Hall', 'Computer Science', 'Artificial Intelligence', '2022-12-04', '2022-05-26', 6, 1),
(15, 'Mariana', 'Riveros', 'Computer Science', 'Internet Programming', '2022-12-04', '2022-05-26', 6, 1),
(16, 'Hank ', 'South', 'Computer Science', 'Internet Programming', '2022-12-04', '2022-05-26', 6, 4),
(17, 'Josh', 'Deforest', 'Computer Science', 'Internet Programming', '2022-12-04', '2022-05-28', 6, 4),
(18, 'Nick', 'Ball', 'Computer Science', 'Internet Programming', '2022-12-04', '2022-05-28', 6, 4),
(19, 'Blake', 'Green', 'Computer Science', 'Information Science', '2022-12-04', '2022-05-26', 6, 3),
(20, 'Frank', 'Garcia', 'Computer Science', 'Information Science', '2022-12-04', '2022-05-28', 6, 3),
(21, 'Cyrus', 'Sky', 'Computer Science', 'Software', '2022-12-04', '2022-05-26', 6, 1),
(22, 'Helena', 'Smith', 'Computer Science', 'Software', '2022-12-04', '2022-05-26', 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `certificatecategory`
--

CREATE TABLE `certificatecategory` (
  `certificateId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificatecategory`
--

INSERT INTO `certificatecategory` (`certificateId`, `categoryId`) VALUES
(1, 4),
(2, 4),
(3, 5),
(4, 5),
(5, 3),
(7, 1),
(11, 2),
(12, 2),
(13, 2),
(14, 1),
(15, 4),
(16, 4),
(17, 4),
(18, 4),
(19, 3),
(20, 3),
(21, 5),
(22, 5);

-- --------------------------------------------------------

--
-- Table structure for table `certificatedetails`
--

CREATE TABLE `certificatedetails` (
  `id` int(11) NOT NULL,
  `certificatename` text DEFAULT NULL,
  `certificatedescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `certificatedetails`
--

INSERT INTO `certificatedetails` (`id`, `certificatename`, `certificatedescription`) VALUES
(1, 'Certificate in Computer Coding', 'Five of the most in-demand programming Languages: C++, C#, Java, PHP, and Python are the right tools that can be used to build anything are introduced.'),
(2, 'Certificate in Systems Engineering', 'The Systems Engineering Certificate Program provides the key skills and knowledge essential for successful systems engineering in today’s rapidly changing environment.'),
(3, 'Certificate in Cybersecurity', 'The Certificate is designed for students pursuing professional employment in information security. The recipients will acquire the basic skills needed for an entry-level career in cybersecurity.'),
(4, 'Certificate in Website and Internet Applications Development', 'This Program in Website and Internet Applications Development prepares students to design, create and administer interactive websites and applications that utilize client and server side programming technologies.');

-- --------------------------------------------------------

--
-- Table structure for table `requiredcourses`
--

CREATE TABLE `requiredcourses` (
  `id` int(11) NOT NULL,
  `coursename` varchar(255) DEFAULT NULL,
  `coursecode` varchar(255) NOT NULL DEFAULT '0',
  `coursedescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requiredcourses`
--

INSERT INTO `requiredcourses` (`id`, `coursename`, `coursecode`, `coursedescription`) VALUES
(1, 'Introduction to Linux', 'CMPS 260', 'Students will learn basic shell scripting to automate system administration tasks and become familiar with the structure and commands of the Linux operating system.'),
(2, 'Project Management', 'CMPS 392', 'Presents project types from public, business, engineering, and information science fields. Includes selecting, initiating, operating, and managing projects.'),
(3, 'Publishing on the Web I', 'CMPS 218', 'Demonstrates the ability to code static websites in HTML and CSS by hand. Covers building static websites in HTML5 and CSS3, links, tables, color and graphics, frames, forms, multimedia, development life cycle, the modern design principles, Web design best practices, development and testing of web pages.'),
(4, 'Publishing on the Web II', 'CMPS 319', 'Demonstrates the ability to code dynamic and interactive websites in HTML, CSS, and JavaScript by hand. Covers design, development, debugging, testing dynamic and interactive websites, HTML, and Cascading Style Sheets review, introduction to scripting, JavaScript control statements, functions, arrays, objects, JavaScript event handling, XML, Document Object Models (DOM), and building Ajax-enabled internet applications. Develops an understanding of the programming process and programming logic using flowcharts. Introduces Web Development Tool, and current debugging online tools. The final part of the course consists of a presentation, a written final report and a demo of the final website published on a web server. Lab included. Not challengeable.'),
(15, 'Internet Apps Development', 'CMPS 320', 'Covers building Data-Driven Web applications, Customized, Secure, Content Management System using PHP and MySQL, Web Servers, Linux Environment, Structured Query Language (SQL), MySQL, creating a database, PHP basics, Programming with PHP, connecting to MySQL with PHP, form processing, regular expressions, creating dynamic web sites, shopping cart and MySQL Administration. Lab included. Not challengeable.'),
(16, 'C# Programming', 'CMPS 378', 'Covers an overview of .NET technology and the role of C# programming, Visual Studio .NET, C# as a general purpose object oriented programming language, Control Structures, Methods, Arrays, Exception Handling, Strings, Inheritance and Graphic User Interface with Windows Forms, Console and Window Apps. Lab Included. May be taken for letter grade only. Not challengeable.'),
(17, 'Distributed Internet Computing', 'CMPS 480', 'Covers Polymorphism, Interfaces, Abstract Classes, Delegates, Files and Streams, Generics, Language Integrated Query (LINQ), Connecting to a Database in ASP.NET, Database and SQL enabled applications, Web App Development with ASP.NET, ASP.Net AJAX, Web Services and Building a Windows Azure Cloud Computing App. Lab included. Can be taken for letter grade only. Not challengeable.'),
(18, 'Mobile Applications Development', 'CMPS 481', 'Topics include: application architecture, XAML, basic principles, concepts, and constructs of Windows phone applications, Sliverlight and dynamic layout, XNA framework, controls and properties, application bars, navigation, pivot, panorama, and creation of mobile applications; lab included. May be taken for letter grade only. Not challengeable.'),
(19, 'Introduction to Python Programming', 'CMPS 372', 'This course introduces students to the Python programming language with an overview of the basic functionalities of the language and libraries needed to solve a problem in data analytics. Topics include Python syntax (built-in data types, expressions, and statements); control flow (selection and loops); user-defined functions; Object-Oriented programming in Python; built-in functions; strings and things; file and text operations; advanced topics (data analysis in Python). Students will learn the basic elements of programming in Python and how to solve problems in data analytics. Lab included. Letter grade only. Not challengeable.'),
(20, 'Java', 'CMPS 379', 'Covers basic concepts of object oriented programming; Java and OOP classes, packages, and inheritance; and requirements for building a fully functional Java program. Lab included. Can be taken for letter grade only. Not challengeable.'),
(21, 'Data Structures', 'CMPS 385', 'Algorithms and data structures. Arrays. Lists. Stacks and queues. Tree structures. Searching and sorting algorithms. Files. Lab included. Not challengeable.'),
(22, 'Seminar', 'CMPS 370', 'Discussion of new and innovative topics in computer science, computer engineering, and information systems. May be taken for four semester hours for credit. Not challengeable.'),
(23, 'Systems Analysis and Design', 'CMPS 375', 'Examines the information systems life cycle in relation to systems analysis. Presents current tools and techniques of systems analysis in data flow diagrams, data dictionaries, transform descriptions, database descriptions, prototyping, etc. Not challengeable.'),
(25, 'Management Information Systems', 'CMPS 410', 'This course introduces Information Technology as it impacts management of organizations and discusses the development, management and utilization of IT in organizations. This course synthesizes models from management and IT for students to integrate contributions of each discipline to analyze various situations to understand its complexity, and recommend a path that leads to higher levels of performance. The covered topics include planning process and communication process that are influenced by information technology, impact of IT on business models and organizational structure, and develop familiarity of IT technologies, their applications and how they affect individuals, organizations, and society. Not challengeable.'),
(26, 'Systems Architecture', 'CMPS 491', 'Foundations of systems architecture, including classical architecting methods and models. Not challengeable.'),
(27, 'Discrete Mathematics', 'CMPS 327', 'Development of mathematical tools necessary for algorithmic applications in computer science. Includes set theory and logic, various algebraic structures, graph theory, Boolean algebra, and computability theory. Emphasizes applications in computer science.'),
(28, 'Principles of Computer Networks', 'CMPS 368', 'Analyzes the mode of operation and the various interface standards and protocols associated with data networks. Reviews ISO/OSI standards, packet and circuit switched data networks, ISDN, local and wide area networks. Lab included. Not challengeable.'),
(29, 'Local Area Networks', 'CMPS 369', 'Covers LAN, server, client/server, and wireless technology; standardization; operating systems; commercial LAN products; inter-networking devices and protocols; metropolitan area networks; vender specific solutions; LAN administration. Lab included. Not challengeable.'),
(30, 'Programming in C', 'CMPS 366', 'Lab included. Not challengeable. CMPS 366 or CMPS 371 must be taken to meet requirement for Certificate in Cybersecurity.'),
(31, 'Assembly Language', 'CMPS 371', 'Covers structure and principles of assembler operation; macro programming and use of assembly language in high level languages. Lab included. Not challengeable. CMPS 366 or CMPS 371 must be taken to meet requirement for Certificate in Cybersecurity.'),
(32, 'Cyber Security', 'CMPS 420', 'This course discusses the vulnerabilities created by system, hardware and software developers, and their usual exploitation by hackers to attack. The counter measures against these attacks are covered, including: identification and authentication of users and network nodes, access control alternatives to limit the authorized actions by any process, protections mechanisms in a network, intrusion detection, intrusion protection and firewalls, security management, and methods to build trusted computer systems. Students will learn how to manage the risk, and translate the risk reduction through security architecting and systems engineering. Computer security counter measures are deployed throughout an information infrastructure. To build trust into a system, the course covers the topics of security requirements, design, development, integration, test, operation, and maintenance. Finally, the course covers the topic of ethics and professionalism as related to computer security. Lab included. Letter grade only. Not challengeable.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `permissions` int(64) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `password`, `permissions`) VALUES
(1, 'Antonio', 'Flores', 'aflores1@gmail.com', '12345', 3),
(2, 'Joe', 'Smith', 'jSmith@gmail.com', '23456', 3),
(3, 'Ela', 'Mcclain', 'eMacclain@gmail.com', '34567', 3),
(4, 'Oliver', 'Meadows', 'oMeadows@gmail.com', '45678', 3),
(5, 'Travis', 'Conley', 'tConley@gmail.com', '56789', 3),
(6, 'Antonio', 'Flores Marquez', 'aflores@gmail.com', '$2y$10$B7OaL.it7jHRbiu0LJNgoepxTr9TsaorYTt8T1VqlVcIupDnzTESa', 63);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `studentId` (`userId`),
  ADD KEY `certificatedetailsId` (`certificatedetailsId`);

--
-- Indexes for table `certificatecategory`
--
ALTER TABLE `certificatecategory`
  ADD PRIMARY KEY (`certificateId`,`categoryId`),
  ADD KEY `categoryId` (`categoryId`);

--
-- Indexes for table `certificatedetails`
--
ALTER TABLE `certificatedetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requiredcourses`
--
ALTER TABLE `requiredcourses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `certificate`
--
ALTER TABLE `certificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `certificatedetails`
--
ALTER TABLE `certificatedetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `requiredcourses`
--
ALTER TABLE `requiredcourses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `certificate`
--
ALTER TABLE `certificate`
  ADD CONSTRAINT `certificate_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `certificate_ibfk_2` FOREIGN KEY (`certificatedetailsId`) REFERENCES `certificatedetails` (`id`);

--
-- Constraints for table `certificatecategory`
--
ALTER TABLE `certificatecategory`
  ADD CONSTRAINT `certificatecategory_ibfk_1` FOREIGN KEY (`certificateId`) REFERENCES `certificate` (`id`),
  ADD CONSTRAINT `certificatecategory_ibfk_2` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
